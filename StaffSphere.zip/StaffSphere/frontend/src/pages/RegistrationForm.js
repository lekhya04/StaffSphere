import React, { useState } from "react";
import PersonalInfo from "./PersonalInfo";
import QualificationInfo from "./QualificationInfo";
import ExperienceForm from "./ExperienceInfo";
import AdditionalDetailsForm from "./AdditionalInfo";
import UploadsForm from "./Uploads";
import { Button } from "./button";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";

const RegistrationForm = () => {
  const [step, setStep] = useState(1);
  const [completedStages, setCompletedStages] = useState([false, false, false, false, false]);

  const [formData, setFormData] = useState({
    personalInfo: {
      name: "", personalPhone: "", alternativePhone: "", personalEmail: "",
      collegeEmail: "", gender: "", maritalStatus: "", caste: "", facultyID: "",
      aadhaar: "", pan: "", address: ""
    },
    qualificationInfo: {
      educationLevel: "", ugUniversityName: "",  ugLocation: "",  ugRollNumber: "",  ugSpecialization: "",  ugCompletionDate: "",  
      pgUniversityName: "",  pgLocation: "",  pgRollNumber: "",  pgSpecialization: "",  pgCompletionDate: "",  
      phdStatus: "", 
      phdList: []
    },    
    experienceInfo: {
      teachingExp: "", teachingStartDate: "", teachingDuration: "",
      teachingSubjects: [{ subject: "", timesTaught: "" }],
      researchExp: "", researchList: [{ name: "", link: "" }],
      industryExp: "", industryList: [{ company: "", role: "", duration: "" }],
      dateOfJoining: "",dateOfReveal: ""
    },
    additionalDetails: {
      areasOfInterest: [], examList: [{ name: "", examCertificate: "" }],
      certifications: [{ name: "", provider: "", certificationLink: "" }],
      projects: [{ name: "", domain: "", status: "" }],
      memberships: [{ name: "" }]
    },
    uploads: { aadharCard: "", panCard: "", passportPhoto: "" }
  });

  const cleanData = (data) => {
    if (typeof data === "string") {
      return data.trim() === "" ? "NA" : data.trim();
    } else if (Array.isArray(data)) {
      return data.map(cleanData);
    } else if (typeof data === "object" && data !== null) {
      return Object.fromEntries(
        Object.entries(data).map(([key, value]) => [key, cleanData(value)])
      );
    }
    return data;
  };

  const validateStep = () => {
    const { personalInfo, qualificationInfo, experienceInfo, additionalDetails, uploads } = formData;

    if (step === 1) { 
      const requiredFields = [
        personalInfo.name, personalInfo.personalPhone, personalInfo.personalEmail,
        personalInfo.gender, personalInfo.maritalStatus, personalInfo.caste,
        personalInfo.facultyID, personalInfo.aadhaar, personalInfo.pan, personalInfo.address
      ];
      return requiredFields.every((field) => field.trim() !== "");
    }

    if (step === 2) { 
      if (!qualificationInfo) return false;

      if (!qualificationInfo.educationLevel || qualificationInfo.educationLevel.trim() === "") return false;

      const requiredUGFields = [
        qualificationInfo.ugUniversityName, qualificationInfo.ugLocation,
        qualificationInfo.ugRollNumber, qualificationInfo.ugSpecialization,
        qualificationInfo.ugCompletionDate
      ];
      if (!requiredUGFields.every(field => field && field.trim() !== "")) return false;

      if (qualificationInfo.educationLevel === "PG") {
        const requiredPGFields = [
          qualificationInfo.pgUniversityName, qualificationInfo.pgLocation,
          qualificationInfo.pgRollNumber, qualificationInfo.pgSpecialization,
          qualificationInfo.pgCompletionDate
        ];
        if (!requiredPGFields.every(field => field && field.trim() !== "")) return false;
      }

      if (qualificationInfo.phdStatus === "Yes") {
        return qualificationInfo.phdList.every((phd) => {
          if (!phd.specialization.trim()) return false;
          if (phd.status === "Completed" && (!phd.completionDate.trim() || !phd.completionCertificate.trim())) return false;
          if (phd.status === "Not Completed" && !phd.expectedYear.trim()) return false;
          if (phd.guide === "Yes" && (!phd.guideName.trim() || !phd.position.trim() || !phd.guideCertificate.trim())) return false;
          return true;
        });
      }
    }

    if (step === 3) { 
      const requiredFields = [experienceInfo.dateOfJoining];

      if (!requiredFields.every((field) => field.trim() !== "")) return false;

      if (experienceInfo.teachingExp === "Yes" && (!experienceInfo.teachingStartDate.trim() || !experienceInfo.teachingDuration.trim())) {
        return false;
      }
      if (experienceInfo.researchExp === "Yes" && experienceInfo.researchList.some((r) => !r.name.trim() || !r.link.trim())) {
        return false;
      }
      if (experienceInfo.industryExp === "Yes" && experienceInfo.industryList.some((i) => !i.company.trim() || !i.role.trim() || !i.duration.trim())) {
        return false;
      }
    }

    if (step === 4) { 
      return additionalDetails.areasOfInterest.length > 0;
    }

    if (step === 5) { 
      const requiredFields = [uploads.aadharCard, uploads.panCard, uploads.passportPhoto];
      return requiredFields.every((file) => file.trim() !== "");
    }

    return true;
  };

  const nextStep = () => {
    if (!validateStep()) {
      alert("❌ Please fill all required fields before proceeding.");
      return;
    }
    setCompletedStages((prevStages) => {
      const updatedStages = [...prevStages];
      updatedStages[step - 1] = true;
      return updatedStages;
    });
    setStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setStep((prev) => prev - 1);
    setCompletedStages((prevStages) => {
      const updatedStages = [...prevStages];
      updatedStages[step - 2] = false; 
      return updatedStages;
    });
  };
  const submitForm = async () => {
    try {
      const updatedFormData = cleanData(formData);
      console.log("📤 Final Form Data to Send:", JSON.stringify(updatedFormData, null, 2));

      const response = await axios.post(
        "http://localhost:5000/api/registration/submit",
        updatedFormData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.success) {
        console.log("Form Submitted Successfully:", response.data);
        window.location.href = "/thank-you";
      } else {
        alert("❌ Registration failed, please try again.");
      }
    } catch (error) {
      console.error("❌ Submission Error:", error.response?.data || error.message);
      alert("Error submitting form.");
    }
  };

  return (
    <>   
    <br></br>
    <br></br>
    <div className="registration-form-container">
      <div className="progress-stages">
        
        {["Personal", "Qualification", "Experience", "Additional Details", "Uploads"].map((label, index) => (
          <div key={index} className={`stage ${step > index ? 'active' : ''} ${completedStages[index] ? `completed-${index + 1}` : ''}`}>
            <span>{index + 1}</span>
            <p>{label}</p>
            
          </div>
        ))}
        
      </div>
      <div className="progress-container">
        <div
          className="progress-bar"
          style={{ width: `${(completedStages.filter(Boolean).length / 5) * 100}%` }}
        ></div>
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ x: "100%", opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: "-100%", opacity: 0 }} transition={{ duration: 0.5 }}>
          {step === 1 && <PersonalInfo formData={formData} setFormData={setFormData} />}
          {step === 2 && <QualificationInfo formData={formData} setFormData={setFormData} />}
          {step === 3 && <ExperienceForm formData={formData} setFormData={setFormData} />}
          {step === 4 && <AdditionalDetailsForm formData={formData} setFormData={setFormData} />}
          {step === 5 && <UploadsForm formData={formData} setFormData={setFormData} />}
        </motion.div>
      </AnimatePresence>

      <nav className="navi">
        {step > 1 && <Button className="back-btn" variant="outline" onClick={prevStep}>Back</Button>}
        {step < 5 ? <Button className="next-btn" onClick={nextStep}>Next</Button> : <Button className="submit-btn" onClick={submitForm}>Submit</Button>}
      </nav>
    </div>
    </>
  );
  
};

export default RegistrationForm;
