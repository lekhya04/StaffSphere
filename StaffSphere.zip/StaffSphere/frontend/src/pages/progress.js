import React from "react";

export const Progress = ({ value }) => {
  return (
    <div className="relative pt-1">
      <div className="flex mb-2 items-center justify-between">
        <div>
          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-teal-600">
            Progress
          </span>
        </div>
      </div>
      <div className="flex mb-2 items-center justify-between">
        <div className="w-full bg-gray-200 rounded-full">
          <div
            className="bg-teal-600 text-xs font-medium text-teal-100 text-center p-0.5 leading-none rounded-l-full"
            style={{ width: `${value}%` }}
          >
            {value}%
          </div>
        </div>
      </div>
    </div>
  );
};
