import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { FaKey, FaEnvelopeOpenText, FaSyncAlt, FaEye, FaEyeSlash } from "react-icons/fa";
import styles from "../styles/ForgotPassword.module.css";

const ForgotPassword = () => {
  const [step, setStep] = useState(1);
  const [facultyID, setFacultyID] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleVerifyUser = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/password/forgot-password", { facultyID, email });
      setSuccess(res.data.message);
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.message || "User verification failed.");
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/password/verify-otp", { facultyID, otp });
      setSuccess(res.data.message);
      setStep(3);
    } catch (err) {
      setError(err.response?.data?.message || "Invalid OTP.");
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    try {
      const res = await axios.post("http://localhost:5000/api/password/reset-password", { facultyID, newPassword });
      setSuccess(res.data.message);
      setTimeout(() => navigate("/"), 3000);
    } catch (err) {
      setError(err.response?.data?.message || "Password reset failed.");
    }
  };

  return (
    <div className={styles.container}>
      <h2>Password Reset</h2>

      {/* Progress Bar */}
      <div className={styles.progressContainer}>
        <div className={`${styles.step} ${step >= 1 ? styles.active : ""}`}>
          <FaKey className={styles.icon} />
          <p>Verify</p>
        </div>
        <div className={`${styles.line} ${step >= 2 ? styles.activeLine : ""}`}></div>
        <div className={`${styles.step} ${step >= 2 ? styles.active : ""}`}>
          <FaEnvelopeOpenText className={styles.icon} />
          <p>OTP</p>
        </div>
        <div className={`${styles.line} ${step >= 3 ? styles.activeLine : ""}`}></div>
        <div className={`${styles.step} ${step >= 3 ? styles.active : ""}`}>
          <FaSyncAlt className={styles.icon} />
          <p>Reset</p>
        </div>
      </div>

      {/* Error & Success Messages */}
      {error && <p className={styles.error}>{error}</p>}
      {success && <p className={styles.success}>{success}</p>}

      {/* Step 1: Faculty ID & Email */}
      {step === 1 && (
        <form onSubmit={handleVerifyUser}>
          <input type="text" className={styles.input1} placeholder="Faculty ID" value={facultyID} onChange={(e) => setFacultyID(e.target.value)} required />
          <input type="email" className={styles.input1} placeholder="Personal Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <button className={styles.step1} type="submit">Send OTP</button>
        </form>
      )}

      {/* Step 2: OTP */}
      {step === 2 && (
        <form onSubmit={handleVerifyOTP}>
          <input type="text" className={styles.input1} placeholder="Enter OTP" value={otp} onChange={(e) => setOtp(e.target.value)} required />
          <button className={styles.step2} type="submit">Verify OTP</button>
        </form>
      )}

      {/* Step 3: Reset Password */}
      {step === 3 && (
        <form onSubmit={handleResetPassword}>
          <div className={styles.passwordField}>
            <input className={styles.input1} type={showPassword ? "text" : "password"} placeholder="New Password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
            <span className={styles.eyeIcon} onClick={togglePasswordVisibility}>{showPassword ? <FaEyeSlash /> : <FaEye />}</span>
          </div>
          <input className={styles.input1} type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          <button className={styles.step3} type="submit">Reset Password</button>
        </form>
      )}
    </div>
  );
};

export default ForgotPassword;
