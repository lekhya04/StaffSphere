import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/Login.module.css";
import { Eye, EyeOff } from "lucide-react";

const Login = () => {
  const [credentials, setCredentials] = useState({ facultyID: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false); // Added loading state
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(""); 
    setLoading(true); 
    console.log("Sending credentials:", credentials); // Debugging
    try {

      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include", 
        body: JSON.stringify(credentials),
      });
      
      const data = await response.json();
      console.log("Response from backend:", data);

      if (response.ok) {
        alert("Login successful! Redirecting...");
        localStorage.setItem("token", data.token); // Store token
        navigate("/faculty-home");
      } else {
        setError(data.message || "Invalid login credentials.");
      }
    } catch (error) {
      console.error("Login error:", error);
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false); // Re-enable button
    }
  };

  return (
    <div className={styles["login-container"]}>
      <div className={styles["login-box"]}>
      <h2>Faculty Login</h2>
        {error && <p className={styles["error-message"]}>{error}</p>} {/* Error display */}
        <form onSubmit={handleSubmit}>
          <div className={styles["input-group"]}>
            <label>Faculty ID</label>
            <input
              type="text"
              name="facultyID"
              placeholder="Enter your Faculty ID"
              value={credentials.facultyID}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles["input-group"]}>
            <label>Password</label>
            <div className={styles["password-container"]}>
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Enter your password"
                value={credentials.password}
                onChange={handleChange}
                required
              />
              <span onClick={() => setShowPassword(!showPassword)}>
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </span>
            </div>
          </div>
          <div className={styles["options"]}>
            <Link to="/forgot-password" className={styles["forgot-password"]}>
              Forgot Password?
            </Link>
          </div>
          <button type="submit" className={styles["login-btn"]} disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
          <p className={styles["register-link"]}>
            Don't have an account? <Link to="/register">Sign up</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
