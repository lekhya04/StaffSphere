import styles from "../styles/Admin.module.css";

export default function Checkbox({ checked, onChange }) {
  return (
    <input
      type="checkbox"
      className={styles["admin-checkbox"]}
      checked={checked}
      onChange={onChange}
    />
  );
}
