import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/EditProfile.module.css"; 
import { FaHome, FaUser, FaGraduationCap, FaBriefcase, FaClipboardList, FaFileUpload, FaCheckCircle } from "react-icons/fa";

const EditProfile = () => {
  const navigate = useNavigate();
  const [facultyData, setFacultyData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editRequest, setEditRequest] = useState(true); // Assuming edit mode is active initially

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/faculty-home/profile", { withCredentials: true })
      .then((response) => {
        setFacultyData(response.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load profile data.");
        setLoading(false);
      });
  }, []);

  // ✅ Function to handle "End Edit" and reset editRequestStatus
  const handleEndEdit = async () => {
    try {
      setEditRequest("None"); 
      await axios.post(
        "http://localhost:5000/api/faculty-home/end-edit",
        {},
        { withCredentials: true }
      );

      alert("Editing session ended. Returning to Faculty Home.");
      navigate("/faculty-home"); // Redirect to Faculty Home
    } catch (error) {
      console.error("Error ending edit session:", error);
      alert("Failed to end edit session. Try again.");
    }
  };

  if (loading) return <p>Loading profile...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className={styles.editProfileContainer}>
      <button className={styles["edit-home-btn"]} onClick={() => (window.location.href = "/faculty-home")}>
        <FaHome /> Home
      </button>
      <h1 className={styles.title}>Edit Your Profile</h1>
      <p className={styles.subtitle}>Select a section to edit your details.</p>
      <div className={styles.sectionButtons}>
          <button className={styles.personalInfoBtn} onClick={() => navigate("/edit-profile/edit-personal-info", { state: facultyData })}>
            <FaUser /> Personal Information
          </button>
          <button className={styles.qualificationInfoBtn} onClick={() => navigate("/edit-profile/edit-qualification-info", { state: facultyData })}>
            <FaGraduationCap /> Qualification Information
          </button>
          <button className={styles.experienceInfoBtn} onClick={() => navigate("/edit-profile/edit-experience-info", { state: facultyData })}>
            <FaBriefcase /> Experience Information
          </button>
          <button className={styles.additionalInfoBtn} onClick={() => navigate("/edit-profile/edit-additional-info", { state: facultyData })}>
            <FaClipboardList /> Additional Information
          </button>
          <button className={styles.uploadsBtn} onClick={() => navigate("/edit-profile/edit-uploads", { state: facultyData })}>
            <FaFileUpload /> Uploads 
          </button>
        </div>

        {/* ✅ End Edit Button */}
        <button className={styles.endEditBtn} onClick={handleEndEdit}>
          <FaCheckCircle /> End Edit
        </button>
    </div>
  );
};

export default EditProfile;
