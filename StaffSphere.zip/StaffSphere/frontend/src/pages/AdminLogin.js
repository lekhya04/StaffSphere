import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/AdminLogin.module.css";

const AdminLogin = () => {
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await axios.post("http://localhost:5000/api/admin/auth/login", credentials, {
        withCredentials: true, 
      });

      if (response.data.success) {
        localStorage.setItem("adminToken", response.data.token);
        navigate("/admin"); // Redirect to Admin Dashboard
      } else {
        setError("Invalid credentials");
      }
    } catch (error) {
      setError("Authentication failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles["admin-login-container"]}>
      <div className={styles["admin-login-box"]} style={{ background: 'rgba(255, 255, 255, 0.97)', borderRadius: 16, boxShadow: '0 4px 24px rgba(0,0,0,0.11)', padding: '2.5rem 2.5rem 2rem 2.5rem', minWidth: 320, maxWidth: 340, width: '100%' }}>
        <h2>Admin Login</h2>
        {error && <p className={styles["error-message"]}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <div className={styles["input-group"]}>
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter Admin Username" value={credentials.username} onChange={handleChange} required />
          </div>
          <div className={styles["input-group"]}>
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter Password" value={credentials.password} onChange={handleChange} required />
          </div>
          <button type="submit" className={styles["login-btn"]} disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
