import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Input } from "./input";
import { Label } from "./label";
import axios from "axios"
import { FaMars, FaVenus, FaTransgender } from "react-icons/fa";
import styles from "../styles/Personal.module.css"; 
import btnstyles from "../styles/Edit.module.css";
import RequiredLabel from "./RequiredLabel"; 

const EditPersonalInfo = () => {
  const [errors, setErrors] = useState({});
  const location = useLocation();
  const navigate = useNavigate();

  const facultyData = location.state || { personalInfo: {} };
  const [formData, setFormData] = useState(facultyData);

  useEffect(() => {
    console.log("Received facultyData:", facultyData);
    if (facultyData.personalInfo) {
      setFormData(facultyData);
    }
  }, [facultyData]);

  const validateField = (name, value) => {
    let errorMessage = "";
    
    switch (name) {
      case "personalPhone":
      case "alternativePhone":
        if (!/^\d{10}$/.test(value)) errorMessage = "Enter a valid 10-digit phone number.";
        break;
      case "aadhaar":
        if (!/^\d{12}$/.test(value)) errorMessage = "Enter a valid 12-digit Aadhaar number.";
        break;
      case "personalEmail":
        if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(value)) {
          errorMessage = "Enter a valid email address.";
        }
        break;
      case "collegeEmail":
        if (!/^[a-zA-Z0-9._%+-]+@gcet\.edu\.in$/.test(value)) {
          errorMessage = "Enter a valid college email address (e.g., example@gcet.edu.in).";
        }
        break;
      case "pan":
        if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value)) errorMessage = "Enter a valid PAN number (e.g., ABCDE1234F).";
        break;
      default:
        errorMessage = "";
    }
    setErrors((prevErrors) => ({ ...prevErrors, [name]: errorMessage }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        [name]: value,
      },
    }));
    validateField(name, value);
  };

  const handleGenderSelect = (selectedGender) => {
    setFormData((prev) => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, gender: selectedGender },
    }));
  };

  const handleMaritalStatusSelect = (status) => {
    setFormData((prev) => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, maritalStatus: status },
    }));
  };
  const handleUpdatePersonalInfo = async () => {
    try {
      const updatedData = {
        personalInfo: formData.personalInfo,
      };

      console.log("🚀 Updating Personal Info:", updatedData);

      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/update-profile",
        updatedData,
        { withCredentials: true }
      );

      if (response.data.success) {
        alert("Personal Information updated successfully!");
        navigate("/edit-profile", { state: response.data.updatedProfile }); 
      } else {
        alert("Failed to update personal information.");
      }
    } catch (error) {
      console.error("❌ Update failed:", error);
      alert("Error updating personal information. Try again.");
    }
  };
  return (
    <div className={styles["personal-info"]}>
      <h2 className={styles["section-title"]}>Personal Information</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["perosnal-form-row"]}>
        <div className={styles["perosnal-form-group"]}>
          <Label>{RequiredLabel("Name", true)}</Label>
          <Input type="text" name="name" value={formData.personalInfo.name || ""} onChange={handleChange} placeholder="Enter Your Name" />
        </div>
      </div>

      <div className={styles["perosnal-form-group"]}>
        <Label>{RequiredLabel("Phone Number", true)}</Label>
        <div className={styles["perosnal-phone-fields"]}>
          <Input required type="tel" name="personalPhone" value={formData.personalInfo.personalPhone || ""} onChange={handleChange} placeholder="Personal Phone" />
          {errors.personalPhone && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.personalPhone}</p>}
          <Input required type="tel" name="alternativePhone" value={formData.personalInfo.alternativePhone || ""} onChange={handleChange} placeholder="Alternate Phone" />
          {errors.alternativePhone && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.alternativePhone}</p>}
        </div>
      </div>

      <div className={styles["perosnal-form-group"]}>
        <Label>{RequiredLabel("Email", true)}</Label>
        <div className={styles["perosnal-email-fields"]}>
          <Input required type="email" name="personalEmail" value={formData.personalInfo.personalEmail || ""} onChange={handleChange} placeholder="Personal Email" />
          {errors.personalEmail && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.personalEmail}</p>}
          <Input required type="email" name="collegeEmail" value={formData.personalInfo.collegeEmail || ""} onChange={handleChange} placeholder="College Email" />
          {errors.collegeEmail && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.collegeEmail}</p>}
        </div>
      </div>

      <div className={styles["perosnal-form-group-container"]}>
        <div className={styles["perosnal-gender-marital"]}>
          <Label>{RequiredLabel("Gender", true)}</Label>
          <div className={styles["perosnal-button-group"]}>
            <button required type="button" className={formData.personalInfo.gender === "Male" ? styles["selected"] : ""} onClick={() => handleGenderSelect("Male")}>
              <FaMars /> Male
            </button>
            <button required type="button" className={formData.personalInfo.gender === "Female" ? styles["selected"] : ""} onClick={() => handleGenderSelect("Female")}>
              <FaVenus /> Female
            </button>
            <button required type="button" className={formData.personalInfo.gender === "Other" ? styles["selected"] : ""} onClick={() => handleGenderSelect("Other")}>
              <FaTransgender /> Other
            </button>
          </div>
        </div>
        <div className={styles["perosnal-gender-marital"]}>
          <Label>{RequiredLabel("Marital Status", true)}</Label>
          <div className={styles["perosnal-button-group"]}>
            <button required type="button" className={formData.personalInfo.maritalStatus === "Married" ? styles["selected"] : ""} onClick={() => handleMaritalStatusSelect("Married")}>
              Married
            </button>
            <button required type="button" className={formData.personalInfo.maritalStatus === "Unmarried" ? styles["selected"] : ""} onClick={() => handleMaritalStatusSelect("Unmarried")}>
              Unmarried
            </button>
          </div>
        </div>
      </div>

      <div className={styles["perosnal-form-group"]}>
        <Label>{RequiredLabel("Caste", true)}</Label>
        <Input required type="text" name="caste" value={formData.personalInfo.caste || ""} onChange={handleChange} placeholder="Caste" />
      </div>
      <div className={styles["perosnal-form-group"]}>
        <label>{RequiredLabel(" GCET Faculty ID", true)}</label>
        <input
            type="text"
            name="facultyID"
            placeholder="Enter Your Faculty ID"
            value={formData.personalInfo?.facultyID || ""}
            onChange={handleChange}
        />
      </div>

      <div className={styles["perosnal-form-row"]}>
        <div className={styles["perosnal-form-group"]}>
          <Label>{RequiredLabel("Aadhar Number", true)}</Label>
          <Input required type="text" name="aadhaar" value={formData.personalInfo.aadhaar || ""} onChange={handleChange} placeholder="Aadhaar Number" />
          {errors.aadhaar && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.aadhaar}</p>}
        </div>
        <div className={styles["perosnal-form-group"]}>
          <Label>{RequiredLabel("Pan Number", true)}</Label>
          <Input required type="text" name="pan" value={formData.personalInfo.pan || ""} onChange={handleChange} placeholder="PAN Number" />
          {errors.pan && <p className="error" style={{ color: 'red', fontSize: '12px' }}>{errors.pan}</p>}
        </div>
      </div>

      <div className={styles["perosnal-form-group"]}>
        <Label>{RequiredLabel("Address", true)}</Label>
        <textarea required name="address" value={formData.personalInfo.address || ""} onChange={handleChange} placeholder="Address" className={styles["perosnal-address-field"]} />
      </div>
      <button 
        className={btnstyles["edit-backButton"]} 
        onClick={() => navigate("/edit-profile")} // Navigate back to Edit Profile page
      >
        🔙 Back
      </button>

      <button 
        className={btnstyles["edit-updateButton"]} 
        onClick={handleUpdatePersonalInfo} // Call handleUpdate function
      >
        Update Personal Details
      </button>

    </div>
  );
};

export default EditPersonalInfo;
