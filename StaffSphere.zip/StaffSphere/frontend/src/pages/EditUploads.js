import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import styles from "../styles/Uploads.module.css"; 
import btnstyles from "../styles/Edit.module.css";
import RequiredLabel from "./RequiredLabel"; 
import axios from "axios";

const EditUploadsForm = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const facultyData = location.state || { uploads: {} };
  const [formData, setFormData] = useState(facultyData);
  const [errors, setErrors] = useState({});


  useEffect(() => {
    console.log("Received facultyData:", facultyData);
    if (facultyData.uploads) {
      setFormData(facultyData);
    }
  }, [facultyData]);

  const validateDriveLink = (link) => {
    const driveLinkPattern = /https?:\/\/(drive\.google\.com\/.*)/;
    return driveLinkPattern.test(link);
  };

  const handleInputChange = (e, fieldName) => {
    const value = e.target.value;
    setFormData((prev) => ({
      ...prev,
      uploads: {
        ...prev.uploads,
        [fieldName]: value,
      },
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [fieldName]: validateDriveLink(value) ? "" : "Enter a valid Google Drive link.",
    }));
  };
  const handleUpdateUploads = async () => {
    try {
      const updatedData = { uploads: formData.uploads };

      console.log("🚀 Updating Uploads:", updatedData);

      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/update-profile",
        updatedData,
        { withCredentials: true }
      );

      if (response.data.success) {
        alert("Uploads updated successfully!");
        navigate("/edit-profile", { state: response.data.updatedProfile });
      } else {
        alert("Failed to update uploads.");
      }
    } catch (error) {
      console.error("❌ Update failed:", error);
      alert("Error updating uploads. Try again.");
    }
  };
  return (
    <div className={styles["uploads-container"]}>
      <h2 className={styles["uploads-title"]}>Upload Documents</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["uploads-row"]}>
        <div className={styles["uploads-group"]}>
          <label className={styles["uploads-label"]}>{RequiredLabel("Aadhar Card Link", true)}</label>
          <input
            className={styles["uploads-input"]}
            type="text"
            placeholder="Enter Google Drive link"
            value={formData.uploads?.aadharCard || ""}
            onChange={(e) => handleInputChange(e, "aadharCard")}
          />
          {errors.aadharCard && <p style={{ color: "red" }}>{errors.aadharCard}</p>}

        </div>

        <div className={styles["uploads-group"]}>
          <label className={styles["uploads-label"]}>{RequiredLabel("PAN Card Link", true)}</label>
          <input
            className={styles["uploads-input"]}
            type="text"
            placeholder="Enter Google Drive link"
            value={formData.uploads?.panCard || ""}
            onChange={(e) => handleInputChange(e, "panCard")}
          />
          {errors.panCard && <p style={{ color: "red" }}>{errors.panCard}</p>}
        </div>
      </div>

      <div className={`${styles["uploads-group"]} ${styles["uploads-passport"]}`}>
        <label className={styles["uploads-label"]}>{RequiredLabel("Passport Size Photo Link", true)}</label>
        <input
          className={styles["passport"]}
          type="text"
          placeholder="Enter Google Drive link"
          value={formData.uploads?.passportPhoto || ""}
          onChange={(e) => handleInputChange(e, "passportPhoto")}
        />
        {errors.passportPhoto && <p style={{ color: "red" }}>{errors.passportPhoto}</p>}
      </div>
      <button 
        className={btnstyles["edit-backButton"]} 
        onClick={() => navigate("/edit-profile")} // Navigate back to Edit Profile page
      >
        🔙 Back
      </button>

      <button 
        className={btnstyles["edit-updateButton"]} 
        onClick={handleUpdateUploads} // Call handleUpdate function
      >
        Update Upload Details
      </button>

    </div>
  );
};

export default EditUploadsForm;
