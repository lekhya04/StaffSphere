import React, { useEffect } from "react";
import confetti from "canvas-confetti";
import { useNavigate } from "react-router-dom";
import styles from'../styles/ThankYou.module.css';

const ThankYou = () => {
  const navigate = useNavigate();

  useEffect(() => {
    confetti({
      particleCount: 200,
      spread: 100,
      origin: { y: 0.6 }
    });
  }, []);

  return (
    <div className={styles["thank-you-container"]}>
      <div className={styles["thank-you-card"]}>
        <h1 className={styles["thank-you-heading"]}>Thank You for Registering!</h1>
        <p className={styles["thank-you-message"]}>Your details have been successfully saved.</p>
        <button className={styles["thank-you-button"]} onClick={() => navigate("/")}>
          Back to Home
        </button>
      </div>
    </div>
  );
};

export default ThankYou;
