export const Button = ({ className = "", onClick, children }) => {
  return (
    <button
      className={`px-4 py-2 rounded-md font-semibold text-white focus:outline-none transition duration-200 ease-in-out 
        ${className || "bg-teal-600 hover:bg-teal-700"}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};
