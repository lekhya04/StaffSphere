import React, {useEffect, useState } from "react";
import {useNavigate} from "react-router-dom";
import axios from "axios";
import styles from "../styles/Admin.module.css"; 
import Modal from "../pages/Modal.js"; // Adjust the path if needed
import { Pie, Bar } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
ChartJS.register(ArcElement, Tooltip, Legend);

const AdminPage = () => {
  const [selectedFilters, setSelectedFilters] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [loading, setLoading] = useState(true); 
  const [endDate, setEndDate] = useState("");
  const [selectedSubFilters, setSelectedSubFilters] = useState({});
  const [error] = useState("");
  const [showRevealForm, setShowRevealForm] = useState(false);
  const [facultyID, setFacultyID] = useState("");
  const [revealMessage, setRevealMessage] = useState("");
  const [editRequests, setEditRequests] = useState([]); // Stores pending edit requests
  const [showEditRequests, setShowEditRequests] = useState(false); // Controls visibility
  const [showSubFilterModal, setShowSubFilterModal] = useState(null); // Tracks which filter's modal is open
  const [chartData, setChartData] = useState(null); // ✅ Store chart data
  const [showCharts, setShowCharts] = useState(false); 
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false, // ✅ Allow manual sizing
    plugins: {
      legend: {
        position: "top", // ✅ Adjust legend position
      },
    },
  };

  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/admin/auth/dashboard", { withCredentials: true })
      .then(() => {
        setLoading(false);
      })
      .catch(() => {
        navigate("/admin-login"); 
      });
  }, [navigate]);

    const handleLogout = async () => {
      try {
        await axios.post("http://localhost:5000/api/admin/auth/logout", {}, { withCredentials: true });
        navigate("/"); 
      } catch (error) {
        console.error("Logout failed:", error);
      }
    };

  if (loading) return <p>Loading...</p>; 
  if (error) return <p>{error}</p>;

  const filterOptions = [
    {
      label: "Done PhD",
      value: "phd",
      subFilters: [
        "All Details", "PhD Specialization", "Status", "Completion Certificate", "Guide Details",
        "Phone Number", "Email"
      ]
    },
    {
      label: "Teaching Experience",
      value: "teaching",
      subFilters: [
        "All Details", "Teaching Duration", "Start Date", "Subjects Taught",
        "Phone Number", "Email"
      ]
    },
    {
      label: "Researches Done",
      value: "research",
      subFilters: [
        "All Details", "Research Type",
        "Phone Number", "Email"
      ]
    },
    {
      label: "Industry Experience",
      value: "industry",
      subFilters: [
        "Industry Experience", "Phone Number", "Email"
      ]
    },
    {
      label: "Faculty Details",
      value: "facultyDetails",
      subFilters: [
        "All Details", "Phone Number", "Email", "Gender", "Marital Status", "Caste", "Aadhaar", 
        "PAN", "Address"
      ]
    },
    {
      label: "Area of Interest",
      value: "areaOfInterest",
    },
    {
      label: "Education Details",
      value: "educationDetails",
      subFilters: [
        "Education Level","UG","PG"
      ]
    },
    {
      label: "Date of Joining",
      value: "dateOfJoining",
    },
    {
      label: "Projects Worked",
      value: "projects",
      subFilters: [
        "Project Details","Phone Number", "Email"
      ]
    },
    {
      label: "Competitive Exams Given",
      value: "competitiveExams",
      subFilters: [
        "Exam Details", "Phone Number", "Email"
      ]
    },
    {
      label: "Certifications Have",
      value: "certifications",
      subFilters: [
        "Certification Details", "Phone Number", "Email"
      ]
    },
    {
      label: "Memberships",
      value: "memberships",
      subFilters: [
        "Membership Name","Phone Number", "Email"
      ]
    }
  ];
  
  const handleRevealSubmit = async () => {
    if (!facultyID.trim()) {
      setRevealMessage("Please enter a Faculty ID.");
      return;
    }
  
    try {
      const response = await axios.post("http://localhost:5000/api/admin/reveal-faculty", { facultyID });
      setRevealMessage(response.data.message);
      setFacultyID("");
    } catch (error) {
      console.error("Error revealing faculty:", error);
      setRevealMessage("Failed to reveal faculty. Please try again.");
    }
  };
  const handleEditRequestsClick = async () => {
    setShowEditRequests((prev) => !prev); // Toggle visibility
  
    if (!showEditRequests) { // Only fetch when opening the panel
      try {
        const response = await axios.get("http://localhost:5000/api/admin/edit-requests");
        setEditRequests(response.data.requests); 
      } catch (error) {
        console.error("🔥 Error fetching edit requests:", error);
      }
    }
  };
  
  const handleApprove = async (facultyID) => {
    try {
      const response = await axios.post("http://localhost:5000/api/admin/approve-edit", { facultyID });
  
      if (response.data.success) {
        alert(`✅ Edit request for ${facultyID} approved.`);
        setEditRequests((prevRequests) => prevRequests.filter((req) => req.facultyID !== facultyID));
      }
    } catch (error) {
      console.error("🔥 Error approving edit request:", error);
      alert("❌ Failed to approve edit request.");
    }
  };
  
  const handleDecline = async (facultyID) => {
    try {
      const response = await axios.post("http://localhost:5000/api/admin/decline-edit", { facultyID });
  
      if (response.data.success) {
        alert(`❌ Edit request for ${facultyID} declined.`);
        setEditRequests((prevRequests) => prevRequests.filter((req) => req.facultyID !== facultyID));
      }
    } catch (error) {
      console.error("🔥 Error declining edit request:", error);
      alert("❌ Failed to decline edit request.");
    }
  };

  // ✅ Toggle Main Filters & Open Sub-Filter Modal
  const handleFilterChange = (value) => {
    setSelectedFilters((prevFilters) =>
      prevFilters.includes(value)
        ? prevFilters.filter((filter) => filter !== value) // Remove if already selected
        : [...prevFilters, value] // Add if not selected
    );

    if (filterOptions.find((option) => option.value === value)?.subFilters) {
      setShowSubFilterModal(value); // Show modal for sub-filters
    }
  };

  // ✅ Handle Sub-Filter Selection
  const handleSubFilterChange = (mainFilter, subValue) => {
    setSelectedSubFilters((prev) => {
      const updatedSubFilters = prev[mainFilter]?.includes(subValue)
        ? prev[mainFilter].filter((item) => item !== subValue) // Remove if unchecked
        : [...(prev[mainFilter] || []), subValue]; // Add if checked

      return { ...prev, [mainFilter]: updatedSubFilters };
    });
  };

  // ✅ Close Sub-Filter Modal but Retain Selections
  const handleCloseSubFilterModal = () => {
    setShowSubFilterModal(null); // Hide modal
  };


  const handleClearSelection = () => {
    setSelectedFilters([]);
    setSelectedSubFilters({});
  };
  
  const handleClearDates = () => {
    setStartDate("");
    setEndDate("");
  }

  const handleExport = async () => {
    if (!startDate || !endDate) {
      alert("Please select both Start Date and End Date.");
      return;
    }
    if (selectedFilters.length === 0) {
      alert("Please select at least one filter before exporting.");
      return;
    }
    
    
    setIsLoading(true);
    try {
      const response = await axios.post(
        "http://localhost:5000/api/admin/export",
        { startDate, endDate, filters: selectedFilters, subFilters: selectedSubFilters },
        { responseType: "blob" }
      );


      const today = new Date().toISOString().slice(0, 10);
      const filterNames = selectedFilters.join("_");
      const fileName = `${today}_${filterNames}.xlsx`;

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      fetchChartData();
    } catch (error) {
      console.error("Error exporting data:", error);
      alert("Failed to export data. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  const fetchChartData = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/admin/chart-data",
        { startDate, endDate, filters: selectedFilters }
      );
      console.log("Chart Data Response:", response.data);
      if (response.data && Object.keys(response.data).length > 0) {
        setChartData(response.data);
        setShowCharts(true); // ✅ Show only if data is present
      } else {
        console.warn("Empty Chart Data Received");
        alert("No data found for the selected criteria.");
      }
    } catch (error) {
      console.error("Error fetching chart data:", error);
      alert("Failed to load chart data.");
    }
  };
  

  return (
    <div className={styles.maincontainer}>
      <div className={styles.buttonModalContainer}>
        <div className={styles.buttonContainer}>
          <button className={styles.editRequestButton} onClick={handleEditRequestsClick}>
            📝 {showEditRequests ? "Close Edit Requests" : "Edit Requests"}
          </button>          
          <button className={styles.revealButton} onClick={() => setShowRevealForm(true)}>🔍 Releave Faculty</button>
          <button className={styles.statsButton} onClick={() => navigate("/admin/stats")}>
            📊 Stats
          </button>
          <button className={styles.logoutButton} onClick={handleLogout}>Logout</button>
        </div>

        {/* Modals */}
        <Modal isOpen={showEditRequests} onClose={() => setShowEditRequests(false)}>
          <div className={styles.modalContent}>
            {/* Close Button inside the modal */}
            <button className={styles.closeButton} onClick={() => setShowEditRequests(false)}>❌</button>
            
            <h3>Pending Edit Requests</h3>
            {editRequests.length === 0 ? (
              <p>No pending edit requests.</p>
            ) : (
              <div className={styles.requestList}>
                {editRequests.map((request) => (
                  <div key={request.facultyID} className={styles.requestCard}>
                    <span className={styles.facultyDetails}>
                      <strong>{request.name}</strong>
                      <small>(ID: {request.facultyID})</small>
                    </span>
                    <div className={styles.requestButtons}>
                      <button onClick={() => handleApprove(request.facultyID)} className={styles.approveButton}>
                        ✅ Approve
                      </button>
                      <button onClick={() => handleDecline(request.facultyID)} className={styles.declineButton}>
                        ❌ Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Modal>

        <Modal 
          isOpen={showRevealForm} 
          onClose={() => {
            setShowRevealForm(false);
            setRevealMessage(""); // ✅ Clear the message when closing
          }}>
          <div className={styles.modalContent}>
            {/* Close Button inside the modal */}
            <button 
              className={styles.closeButton} 
              onClick={() => {
                setShowRevealForm(false);
                setRevealMessage(""); // ✅ Clear the message when closing
              }}
            >
              ❌
            </button>

            <h3>Releave Faculty</h3>
            <input
              type="text"
              placeholder="Enter Faculty ID"
              value={facultyID}
              onChange={(e) => setFacultyID(e.target.value)}
              className={styles.revealInput}
            />
            <button onClick={handleRevealSubmit} className={styles.revealSubmitButton}>
              Confirm Releave
            </button>

            {/* ✅ Show message only when present */}
            {revealMessage && <p className={styles.revealMessage}>{revealMessage}</p>}
          </div>
      </Modal>


      </div>
      <div className={styles.adminContainer}>
        <h1 className={styles.title}>Admin Panel</h1>
        {/* ✅ Container for Date & Filters */}
        <div className={styles.dateFilterWrapper}>
          {/* ✅ Date Section (Left Side) */}
          <div className={styles.dateContainer}>
            <label className={styles.dateLabel}>
              Start Date:
              <input 
                type="date" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)} 
                className={styles.dateInput} 
              />
            </label>
            <label className={styles.dateLabel}>
              End Date:
              <input 
                type="date" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)} 
                className={styles.dateInput} 
              />
            </label>
          </div>
          <div className={`${styles.filterSection} ${!(startDate && endDate) ? styles.disabledFilters : ""}`}>
            <h3 className={styles.filterTitle}>Select Filters</h3>
            <div className={styles.filterGrid}>
              {filterOptions.map((filter) => (
                <div key={filter.value} className={styles.filterItem}>
                  <label className={styles.checkboxLabel}>
                    <input 
                      type="checkbox" 
                      value={filter.value} 
                      checked={selectedFilters.includes(filter.value)} 
                      onChange={() => handleFilterChange(filter.value)} 
                      className={styles.checkbox} 
                      disabled={!(startDate && endDate)} // 🔹 Disable if dates are not selected
                    />
                    {filter.label}
                  </label>

                  {/* ✅ Show 'Select Sub-Filters' Button (Disabled if Dates Missing) */}
                  {filter.subFilters && selectedFilters.includes(filter.value) && (
                    <button 
                      className={styles.subFilterButton} 
                      onClick={() => setShowSubFilterModal(filter.value)}
                      disabled={!(startDate && endDate)} // 🔹 Disable if dates are not selected
                    >
                      Select Sub-Filters
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className={styles.filterbuttonContainer}>
                <button className={styles.clearButton} onClick={handleClearDates}>
                  Clear Dates
                </button>
                <button
                  className={styles.exportButton}
                  onClick={handleExport}
                  disabled={isLoading}
                >
                  {isLoading ? "Exporting..." : "Export to Excel"}
                </button>
                <button className={styles.clearButton} onClick={handleClearSelection}>
                  Clear Selection
                </button>
              </div>
          </div>
        </div>
        {/* ✅ Subfilter Modal */}
        {showSubFilterModal && (
          <div className={styles.subFilterModalOverlay}>
            <div className={styles.subFilterModal}>
              <h3 className={styles.subFilterTitle}>Select Sub-Filters for {showSubFilterModal}</h3>
              <div className={styles.subFilterGrid}>
                {filterOptions.find(f => f.value === showSubFilterModal)?.subFilters.map((sub) => (
                  <label key={sub} className={styles.subFilterCheckboxLabel}>
                    <input 
                      type="checkbox" 
                      value={sub} 
                      checked={selectedSubFilters[showSubFilterModal]?.includes(sub)} 
                      onChange={() => handleSubFilterChange(showSubFilterModal, sub)} 
                      className={styles.subFilterCheckbox} 
                    />
                    {sub}
                  </label>
                ))}
              </div>

              <button className={styles.subFilterCloseButton} onClick={handleCloseSubFilterModal}>
                Close
              </button>
            </div>
          </div>
        )}
      </div>
      {/* ✅ Charts Section (Only show after export) */}
      {showCharts && chartData && Object.keys(chartData).length > 0 ? (
      <div className={styles.chartSection}>
        <h2 className={styles.chartTitle}>📊 Exported Data Analysis</h2>
        <div className={styles.chartsGrid}>
          {Object.keys(chartData).map((category, index) => {
            const categoryData = chartData[category];

            // ✅ Ensure categoryData is valid before rendering
            if (!categoryData || Object.keys(categoryData).length === 0) return null;

            const data = {
              labels: Object.keys(categoryData),
              datasets: [
                {
                  data: Object.values(categoryData),
                  backgroundColor: ["#3498db", "#e74c3c", "#2ecc71", "#f1c40f", "#9b59b6"],
                },
              ],
            };

            return (
              <div key={index} className={styles.chartCard}>
                <h3>{category}</h3>
                {category === "Date of Joining" ? (
                  <div style={{ width: "300px", height: "300px" }}>
                    <Bar data={data} options={chartOptions} />
                  </div>
            ) : (
                <div style={{ width: "300px", height: "300px" }}>
                  <Pie data={data} options={chartOptions} />
                </div>            
              )}
              </div>
            );
          })}
        </div>
      </div>
      ) : (
        <p>No data available for the selected filters.</p>
    )}


    </div>
  );
};

export default AdminPage;
