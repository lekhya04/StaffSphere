import React, { useState, useEffect } from "react";
import styles from "../styles/FacultyHomeContent.module.css";

const quotes = [
  { 
    text: "Education is the most powerful weapon which you can use to change the world.", 
    author: "Nelson Mandela", 
    gradient: "linear-gradient(135deg, #6a11cb, #2575fc)", 
    animation: "fadeIn" 
  },
  { 
    text: "The function of education is to teach one to think intensively and to think critically.", 
    author: "Martin Luther King Jr.", 
    gradient: "linear-gradient(135deg, #4b6cb7, #182848)", 
    animation: "zoomIn" 
  },
  { 
    text: "The beautiful thing about learning is that no one can take it away from you.", 
    author: "B.B. King", 
    gradient: "linear-gradient(135deg, #36096d, #37d5d6)", 
    animation: "rotateIn" 
  },
  { 
    text: "A teacher affects eternity; they can never tell where their influence stops.", 
    author: "Henry Adams", 
    gradient: "linear-gradient(135deg, #200122, #6f0000)", 
    animation: "slideUp" 
  },
  { 
    text: "Tell me and I forget. Teach me and I remember. Involve me and I learn.", 
    author: "Benjamin Franklin", 
    gradient: "linear-gradient(135deg, #7b4397, #dc2430)", 
    animation: "flipIn" 
  }
];

const FacultyHomeContent = () => {
  const [index, setIndex] = useState(0);
  const [fadeClass, setFadeClass] = useState("");

  useEffect(() => {
    setFadeClass(styles[quotes[index].animation]); // Apply animation
    const interval = setInterval(() => {
      setFadeClass(""); // Remove animation before next transition
      setTimeout(() => {
        setIndex((prevIndex) => (prevIndex + 1) % quotes.length);
        setFadeClass(styles[quotes[index].animation]);
      }, 500);
    }, 4000); // Change every 4s

    return () => clearInterval(interval);
  }, [index]);

  return (
    <div className={styles.homeContainer} style={{ background: quotes[index].gradient }}>
      <div className={`${styles.quoteBox} ${fadeClass}`}>
        <p className={`${styles.quoteText} ${fadeClass}`}>“{quotes[index].text}”</p>
        <p className={`${styles.quoteAuthor} ${fadeClass}`}>- {quotes[index].author}</p>
      </div>
    </div>
  );
};

export default FacultyHomeContent;
