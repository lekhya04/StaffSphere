import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import styles from "../styles/Qualification.module.css";
import btnstyles from "../styles/Edit.module.css";
import RequiredLabel from "./RequiredLabel"; 
import axios from "axios";


const EditQualification = () => {
  const defaultPhdList = [
    {
      specialization: "",
      status: "",
      completionDate: "",
      expectedYear: "",
      guide: "",
      guideName: "",
      position: "",
      certificate: null,
      guideCertificate: null,
    },
  ];
  const location = useLocation();
  const navigate = useNavigate();
  
  const facultyData = location.state || { qualificationInfo: {} };
  const [formData, setFormData] = useState(facultyData);

  useEffect(() => {
    console.log("Received facultyData:", facultyData);
    if (facultyData.qualificationInfo) {
      setFormData(facultyData);
      setPhdList(facultyData.qualificationInfo?.phdList || defaultPhdList); // ✅ Ensure phdList is also updated
    }
  }, [facultyData]);

  const validateDriveLink = (link) => {
    const driveLinkPattern = /https?:\/\/(drive\.google\.com\/.*)/;
    return driveLinkPattern.test(link);
  };
  
  const [phdList, setPhdList] = useState(formData.qualificationInfo?.phdList || defaultPhdList);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      qualificationInfo: { ...prev.qualificationInfo, [field]: value },
    }));
  };

  const handlePhdChange = (index, field, value) => {
    const updatedList = [...phdList];
    updatedList[index][field] = value;
    setPhdList(updatedList);
    setFormData((prev) => ({
      ...prev,
      qualificationInfo: { ...prev.qualificationInfo, phdList: updatedList },
    }));
  };

  const handlePhdAdd = () => {
    setPhdList([...phdList, { ...defaultPhdList[0] }]);
  };

  const handlePhdRemove = (index) => {
    const updatedList = phdList.filter((_, i) => i !== index);
    setPhdList(updatedList);
    setFormData((prev) => ({
      ...prev,
      qualificationInfo: { ...prev.qualificationInfo, phdList: updatedList },
    }));
  };

  const handleUpdateQualificationInfo = async () => {
    try {
      const updatedData = {
        qualificationInfo: formData.qualificationInfo,
      };

      console.log("🚀 Updating Qualification Info:", updatedData);

      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/update-profile",
        updatedData,
        { withCredentials: true }
      );

      if (response.data.success) {
        alert("Qualification Information updated successfully!");
        navigate("/edit-profile", { state: response.data.updatedProfile }); // ✅ Pass updated data
      } else {
        alert("Failed to update qualification information.");
      }
    } catch (error) {
      console.error("❌ Update failed:", error);
      alert("Error updating qualification information. Try again.");
    }
  };
  return (
    <div className={styles["qualification-container"]}>
      <h2 className={styles["title"]}>Qualification Details</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["ug-pg-container"]}>
        <div className={styles["inline-fields"]}>
          <div className={styles["form-group"]}>
              <label>{RequiredLabel("Education Level", true)}</label>
              <select
                className={styles["input-field"]}
                value={formData.qualificationInfo?.educationLevel || ""}
                onChange={(e) => handleInputChange("educationLevel", e.target.value)}
              >
                <option value="">Select Highest Education Level</option>
                <option value="UG">Undergraduate (UG)</option>
                <option value="PG">Postgraduate (PG)</option>
              </select>
          </div>
        </div>
        {formData.qualificationInfo?.educationLevel === "PG" && (
          <>
            <h3>Postgraduate (PG) Details</h3>
            <div className={styles["inline-fields"]}>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("PG University Name", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.pgUniversityName || ""}
                  onChange={(e) => handleInputChange("pgUniversityName", e.target.value)}
                  placeholder="Enter PG University Name"
                />
              </div>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("PG University Location", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.pgLocation || ""}
                  onChange={(e) => handleInputChange("pgLocation", e.target.value)}
                  placeholder="Enter PG Location"
                />
              </div>
            </div>
            <div className={styles["three-fields"]}>
              <div className={styles["form-group"]}>
                  <label>{RequiredLabel("PG University Roll Number", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.pgRollNumber || ""}
                    onChange={(e) => handleInputChange("pgRollNumber", e.target.value)}
                    placeholder="Enter PG Roll Number"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("PG     Specialization", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.pgSpecialization || ""}
                    onChange={(e) => handleInputChange("pgSpecialization", e.target.value)}
                    placeholder="Enter PG Specialization"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("PG Completion Date", true)}</label>
                  <input
                    type="date"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.pgCompletionDate || ""}
                    onChange={(e) => handleInputChange("pgCompletionDate", e.target.value)}
                  />
                </div>
            </div>

            {/* Now show UG details if PG is selected */}
            <h3>Undergraduate (UG) Details</h3>
            <div className={styles["inline-fields"]}>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("UG University Name", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.ugUniversityName || ""}
                  onChange={(e) => handleInputChange("ugUniversityName", e.target.value)}
                  placeholder="Enter UG University Name"
                />
              </div>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("UG University Location", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.ugLocation || ""}
                  onChange={(e) => handleInputChange("ugLocation", e.target.value)}
                  placeholder="Enter UG Location"
                />
              </div>
            </div>
            <div className={styles["three-fields"]}>
              <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG University Roll Number", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugRollNumber || ""}
                    onChange={(e) => handleInputChange("ugRollNumber", e.target.value)}
                    placeholder="Enter UG Roll Number"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG Specialization", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugSpecialization || ""}
                    onChange={(e) => handleInputChange("ugSpecialization", e.target.value)}
                    placeholder="Enter UG Specialization"
                  />
                </div>              
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG Completion Date", true)}</label>
                  <input
                    type="date"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugCompletionDate || ""}
                    onChange={(e) => handleInputChange("ugCompletionDate", e.target.value)}
                  />
                </div>
            </div>
          </>
        )}
        {/* If UG is selected, show only UG fields */}
        {formData.qualificationInfo?.educationLevel === "UG" && (
          <>
            <h3>Undergraduate (UG) Details</h3>
            <div className={styles["inline-fields"]}>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("UG University Name", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.ugUniversityName || ""}
                  onChange={(e) => handleInputChange("ugUniversityName", e.target.value)}
                  placeholder="Enter UG University Name"
                />
              </div>
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("UG University Location", true)}</label>
                <input
                  type="text"
                  className={styles["input"]}
                  value={formData.qualificationInfo?.ugLocation || ""}
                  onChange={(e) => handleInputChange("ugLocation", e.target.value)}
                  placeholder="Enter UG Location"
                />
              </div>
            </div>
            <div className={styles["three-fields"]}>
              <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG University Roll Number", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugRollNumber || ""}
                    onChange={(e) => handleInputChange("ugRollNumber", e.target.value)}
                    placeholder="Enter UG Roll Number"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG Specialization", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugSpecialization || ""}
                    onChange={(e) => handleInputChange("ugSpecialization", e.target.value)}
                    placeholder="Enter UG Specialization"
                  />
                </div>              
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("UG Completion Date", true)}</label>
                  <input
                    type="date"
                    className={styles["input"]}
                    value={formData.qualificationInfo?.ugCompletionDate || ""}
                    onChange={(e) => handleInputChange("ugCompletionDate", e.target.value)}
                  />
                </div>
            </div>
          </>
        )}
      </div>

      <div className={styles["form-group"]}>
        <label>{RequiredLabel("Have You Done PhD?", true)}</label>
        <select
          className={styles["input-field"]}
          value={formData.qualificationInfo?.phdStatus || ""}
          onChange={(e) => handleInputChange("phdStatus", e.target.value)}
        >
          <option value="">--select--</option>
          <option value="no">No</option>
          <option value="yes">Yes</option>
        </select>
      </div>
      {formData.qualificationInfo?.phdStatus === "yes" &&
        phdList.map((phd, index) => (
          <div key={index} className={styles["phd-section"]}>
            <div className={styles["phd-header"]}>
              <h3>PhD {index + 1}</h3>
              {phdList.length > 1 && (
                  <button type="button" className={styles["remove-btn"]} onClick={() => handlePhdRemove(index)}>
                    -Remove
                  </button>
                )}            
            </div>
            <div className={styles["form-group"]}>
              <label>{RequiredLabel("Specialization", true)}</label>
              <input
                type="text"
                className={styles["phd-field"]}
                value={phd.specialization}
                onChange={(e) => handlePhdChange(index, "specialization", e.target.value)}
                placeholder="Enter Specialization"
              />
            </div>
            <div className={styles["form-group"]}>
              <label>{RequiredLabel("Status", true)}</label>
              <select className={styles["status-field"]} value={phd.status} onChange={(e) => handlePhdChange(index, "status", e.target.value)}>
                <option value="">Select Status</option>
                <option value="completed">Completed</option>
                <option value="notCompleted">Not Completed</option>
              </select>
            </div>
            {phd.status === "completed" && (
              <div className={styles["inline-fields"]}>
                <div className={styles["form-group"]}>
                  <label>C{RequiredLabel("Date of Completion", true)}</label>
                  <input type="date" className={styles["input"]} onChange={(e) => handlePhdChange(index, "completionDate", e.target.value)} />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("Completion Certificate", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    placeholder="Paste Google Drive Link"
                    value={phd.completionCertificate || ""}
                    onChange={(e) =>
                      handlePhdChange(index, "completionCertificate", e.target.value)
                    }
                  /> 
                  {!validateDriveLink(phd.completionCertificate) && phd.completionCertificate && (
                    <p className="error" style={{ color: 'red', fontSize: '12px' }}>Enter a valid Google Drive link.</p>
                  )}          
                </div>
              </div>
            )}
            {phd.status === "notCompleted" && (
              <div className={styles["form-group"]}>
                <label>{RequiredLabel("Expected Year of Completion", true)}</label>
                <input
                    type="number"
                    className={styles["input"]}
                    value={phd.expectedYear}
                    onChange={(e) => handlePhdChange(index, "expectedYear", e.target.value)}
                    placeholder="Expected Completion Year"
                 />              
              </div>
            )}
            <div className={styles["form-group"]}>
              <label>{RequiredLabel("Did You Take Guidance?", true)}</label>
              <select
                className={styles["status-field"]}
                value={phd.guide}
                onChange={(e) => handlePhdChange(index, "guide", e.target.value)}
              >
                <option value="">--select--</option>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            {phd.guide === "yes" && (
              <div className={styles["inline-fields"]}>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("Guide Name", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={phd.guideName}
                    onChange={(e) => handlePhdChange(index, "guideName", e.target.value)}
                    placeholder="Enter Guide Name"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("Position", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    value={phd.position}
                    onChange={(e) => handlePhdChange(index, "position", e.target.value)}
                    placeholder="Enter Position"
                  />
                </div>
                <div className={styles["form-group"]}>
                  <label>{RequiredLabel("Guide Allotment Order", true)}</label>
                  <input
                    type="text"
                    className={styles["input"]}
                    placeholder="Paste Google Drive Link"
                    value={phd.guideCertificate || ""}
                    onChange={(e) =>
                      handlePhdChange(index, "guideCertificate", e.target.value)
                    }
                  />
                  {!validateDriveLink(phd.guideCertificate) && phd.guideCertificate && (
                    <p className="error" style={{ color: 'red', fontSize: '12px' }}>Enter a valid Google Drive link.</p>
                  )} 
                </div>
              </div>
            )}
          </div>
        ))
      }
      {formData.qualificationInfo?.phdStatus === "yes" && (
        <button className={styles["add-btn"]} onClick={handlePhdAdd}>Add PhD</button>
      )}

        <button 
          className={btnstyles["edit-backButton"]} 
          onClick={() => navigate("/edit-profile")} // Navigate back to Edit Profile page
        >
          🔙 Back
        </button>

        <button 
          className={btnstyles["edit-updateButton"]} 
          onClick={handleUpdateQualificationInfo} // Call handleUpdate function
        >
          Update Qualification Details
        </button>

    </div>
  );
};
export default EditQualification;