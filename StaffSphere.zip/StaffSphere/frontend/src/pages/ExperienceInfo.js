import React, { useEffect } from "react";
import { Button } from "./button";
import styles from "../styles/Experience.module.css";
import RequiredLabel from "./RequiredLabel"; 


const ExperienceForm = ({ formData, setFormData }) => {
  useEffect(() => {
    setFormData((prev) => ({
      ...prev,
      experienceInfo: {
        ...prev.experienceInfo,
        teachingSubjects: prev.experienceInfo?.teachingSubjects || [{ subject: "", timesTaught: "" }],
        researchList: prev.experienceInfo?.researchList || [{ name: "", link: "" }],
        industryList: prev.experienceInfo?.industryList || [{ company: "", role: "", duration: "" }],
      },
    }));
  }, [setFormData]);

  
  const handleChange = (e) => {
    const { name, value } = e.target;
  
    if (name === "dateOfJoining") {
      const date = new Date(value);
      const year = date.getFullYear();
      const month = date.getMonth() + 1; 
  
      let academicYear = "";
      if (month < 6) {
        academicYear = `${year - 1}-${year}`; 
      } else {
        academicYear = `${year}-${year + 1}`; 
      }
  
      setFormData((prev) => ({
        ...prev,
        experienceInfo: {
          ...prev.experienceInfo,
          dateOfJoining: `${value} / ${academicYear}`, 
          dateOfReveal: prev.experienceInfo?.dateOfReveal || "NA",
        },
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        experienceInfo: {
          ...prev.experienceInfo,
          [name]: value,
        },
      }));
    }
  };
  
  const validateDriveLink = (link) => {
    const driveLinkPattern = /https?:\/\/(drive\.google\.com\/.*)/;
    return driveLinkPattern.test(link);
  };

  const handleNestedChange = (section, index, field, value) => {
    setFormData((prev) => ({
      ...prev,
      experienceInfo: {
        ...prev.experienceInfo,
        [section]: prev.experienceInfo[section].map((item, i) =>
          i === index ? { ...item, [field]: value } : item
        ),
      },
    }));
  };

  const addNestedItem = (section, itemTemplate) => {
    setFormData((prev) => ({
      ...prev,
      experienceInfo: {
        ...prev.experienceInfo,
        [section]: [...prev.experienceInfo[section], itemTemplate],
      },
    }));
  };

  const removeNestedItem = (section, index) => {
    setFormData((prev) => ({
      ...prev,
      experienceInfo: {
        ...prev.experienceInfo,
        [section]: prev.experienceInfo[section].filter((_, i) => i !== index),
      },
    }));
  };

  return (
    <div className={styles["experience-section"]}>
      <h2 className={styles["experience-form-title"]}>Experience Details</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["experience-form-group"]}>
        <label>{RequiredLabel("Do You Have Teaching Experience?", true)}</label>
        <select
          name="teachingExp"
          className={styles["experience-long-select"]}
          value={formData.experienceInfo?.teachingExp || "no"}
          onChange={handleChange}
        >
          <option value="no">No</option>
          <option value="yes">Yes</option>
        </select>
      </div>

      {formData.experienceInfo?.teachingExp === "yes" && (
        <div>
          <div className={styles["experience-form-row"]}>
            <label>{RequiredLabel("Started On", true)}</label>
            <input
              type="date"
              name="teachingStartDate"
              value={formData.experienceInfo?.teachingStartDate || ""}
              onChange={handleChange}
            />
          </div>
          <div className={styles["experience-form-row"]}>
            <label>{RequiredLabel("No Of Years Taught", true)}</label>
            <input
              type="number"
              name="teachingDuration"
              value={formData.experienceInfo?.teachingDuration || ""}
              onChange={handleChange}
            />
          </div>

          {formData.experienceInfo?.teachingSubjects.map((subject, index) => (
            <div key={index} className={styles["experience-form-row"]}>
              <label>{RequiredLabel("Subject Taught", true)}</label>
              <input
                type="text"
                value={subject.subject}
                onChange={(e) =>
                  handleNestedChange("teachingSubjects", index, "subject", e.target.value)
                }
              />
              <label>{RequiredLabel("No Of Times Taught", true)}</label>
              <input
                type="number"
                value={subject.timesTaught}
                onChange={(e) =>
                  handleNestedChange("teachingSubjects", index, "timesTaught", e.target.value)
                }
              />
              {index > 0 && (
                <Button type="button" className={styles["experience-remove-btn"]} onClick={() => removeNestedItem("teachingSubjects", index)}>
                  - Remove
                </Button>
              )}
            </div>
          ))}
          <Button type="button" className={styles["experience-add-btn"]} onClick={() => addNestedItem("teachingSubjects", { subject: "", timesTaught: "" })}>
            + Add More
          </Button>
        </div>
      )}

      <div className={styles["experience-form-group"]}>
        <label>{RequiredLabel("Have You Done Any Research?", true)}</label>
        <select
          name="researchExp"
          className={styles["experience-long-select"]}
          value={formData.experienceInfo?.researchExp || "no"}
          onChange={handleChange}
        >
          <option value="no">No</option>
          <option value="yes">Yes</option>
        </select>
      </div>

      {formData.experienceInfo?.researchExp === "yes" && (
        <div>
          {formData.experienceInfo?.researchList.map((item, index) => (
            <div key={index} className={styles["experience-form-row"]}>
              <label>{RequiredLabel("Research Publication Title", true)}</label>
              <input
                type="text"
                value={item.name}
                onChange={(e) =>
                  handleNestedChange("researchList", index, "name", e.target.value)
                }
              />
              <label>{RequiredLabel("Publication Link", true)}</label>
              <input
                type="text"
                value={item.link}
                onChange={(e) =>
                  handleNestedChange("researchList", index, "link", e.target.value)
                }
              />
              {!validateDriveLink(item.link) && item.link && (
                <p className="error" style={{ color: "red", fontSize: "12px" }}>Enter a valid Google Drive link.</p>
              )}
              {index > 0 && (
                <Button type="button" className={styles["experience-remove-btn"]} onClick={() => removeNestedItem("researchList", index)}>
                  - Remove
                </Button>
              )}
            </div>
          ))}
          <Button type="button" className={styles["experience-add-btn"]} onClick={() => addNestedItem("researchList", { type: "", link: "" })}>
            + Add More
          </Button>
        </div>
      )}

      <div className={styles["experience-form-group"]}>
        <label>{RequiredLabel("Do You Have Any Industry Experience?", true)}</label>
        <select
          name="industryExp"
          className={styles["experience-long-select"]}
          value={formData.experienceInfo?.industryExp || "no"}
          onChange={handleChange}
        >
          <option value="no">No</option>
          <option value="yes">Yes</option>
        </select>
      </div>

      {formData.experienceInfo?.industryExp === "yes" && (
        <div>
          {formData.experienceInfo?.industryList.map((item, index) => (
            <div key={index} className={styles["experience-form-row"]}>
              <label>{RequiredLabel("Company Name", true)}</label>
              <input
                type="text"
                value={item.company}
                onChange={(e) =>
                  handleNestedChange("industryList", index, "company", e.target.value)
                }
              />
              <label>{RequiredLabel("Role", true)}</label>
              <input
                type="text"
                value={item.role}
                onChange={(e) =>
                  handleNestedChange("industryList", index, "role", e.target.value)
                }
              />
              <label>{RequiredLabel("Duration Worked (Years)", true)}</label>
              <input
                type="number"
                value={item.duration}
                onChange={(e) =>
                  handleNestedChange("industryList", index, "duration", e.target.value)
                }
              />
              {index > 0 && (
                <Button type="button" className={styles["experience-remove-btn"]} onClick={() => removeNestedItem("industryList", index)}>
                  - Remove
                </Button>
              )}
            </div>
          ))}
          <Button type="button" className={styles["experience-add-btn"]} onClick={() => addNestedItem("industryList", { company: "", role: "", duration: "" })}>
            + Add More
          </Button>
        </div>
      )}
      <br></br>
      <div className={styles["experience-form-row"]}>
        <label>{RequiredLabel("Date Of Joining GCET", true)}</label>
        <input
          type="date"
          name="dateOfJoining"
          value={formData.experienceInfo?.dateOfJoining.split(" / ")[0] || ""}  
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default ExperienceForm;
