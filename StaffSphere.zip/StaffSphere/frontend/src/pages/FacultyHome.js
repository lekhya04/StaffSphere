import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/FacultyHome.module.css"; 
import FacultyHomeContent from "./FacultyHomeContent"; // Home content page
import EditProfile from "./EditProfile"; // Edit Profile page

const FacultyHome = () => {
  const [facultyName, setFacultyName] = useState("");
  const [loading, setLoading] = useState(true);
  const [editRequestStatus, setEditRequestStatus] = useState("");  
  const [activePage, setActivePage] = useState("home"); // Dynamic content area
  const [messages, setMessages] = useState([]); // Chatbot messages
  const [input, setInput] = useState(""); 
  const [botTyping, setBotTyping] = useState(false);  
  const navigate = useNavigate();

  // ✅ Fetch faculty details & edit request status
  useEffect(() => {
    axios.get("http://localhost:5000/api/auth/dashboard", { withCredentials: true })
      .then((response) => {
        setFacultyName(response.data.name);
        setEditRequestStatus(response.data.editRequestStatus || "None"); // Default if undefined
        setLoading(false);
      })
      .catch(() => {
        navigate("/login");
      });
  }, [navigate]);

  // ✅ Handle edit request button click
  const handleRequestEdit = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/request-edit",
        {},
        { withCredentials: true }
      );

      if (response.data.success) {
        setEditRequestStatus("Pending"); 
      } else {
        alert("Failed to send request. Try again later.");
      }
    } catch (error) {
      console.error("Error sending edit request:", error);
      alert("Error sending request.");
    }
  };

  // ✅ Handle logout
  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:5000/api/auth/logout", {}, { withCredentials: true });
      navigate("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  // ✅ Handle chatbot input
  const handleChatSubmit = async () => {
    if (!input.trim()) return;
  
    setMessages((prev) => [...prev, { text: input, sender: "user" }]);
    setInput(""); 
    setBotTyping(true);  

    try {
      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/chatbot",
        { query: input },
        { withCredentials: true }
      );

      const botMessages = response.data.message.split("\n");
      botMessages.forEach((msg, index) => {
        setTimeout(() => {
          setMessages((prev) => [...prev, { text: msg, sender: "bot" }]);
        }, index * 500);
      });

      setTimeout(() => setBotTyping(false), botMessages.length * 500);

    } catch (error) {
      console.error("Chatbot error:", error);
      setMessages((prev) => [...prev, { text: "Error fetching data. Please try again.", sender: "bot" }]);
      setBotTyping(false);
    }
  };

  // ✅ Greet faculty when chatbot opens
  const handleOpenChatbot = () => {
    setActivePage("chatbot");
    if (messages.length === 0) {
      setMessages([{ text: `Hello ${facultyName}, how can I assist you today?`, sender: "bot" }]);
    }
  };

  if (loading) return <p className={styles.loading}>Loading...</p>;

  return (
    <div className={styles.facultyHomeContainer}>
      {/* ✅ Header */}
      <div className={styles.header}>
        <h1>Welcome, {facultyName} 👋</h1>
      </div>

      {/* ✅ Navigation Bar */}
      <nav className={styles.navbar}>
        <button onClick={() => setActivePage("home")}>Home</button>
        <button onClick={handleOpenChatbot}>Chatbot</button>

        {/* ✅ Edit Request / Edit Profile Button */}
        {/* ✅ Edit Request / Edit Profile Button */}
        {editRequestStatus === "Pending" ? (
          <span className={styles.pendingMessage}>⏳ Pending Approval...</span> 
        ) : (
          <button 
            onClick={editRequestStatus === "Approved" ? () => setActivePage("edit-profile") : handleRequestEdit}
          >
            {editRequestStatus === "Approved" ? "Edit Profile" : "Request Profile Edit"}
          </button>
        )}


        <button onClick={() => navigate("/forgot-password")}>Change Password</button>
        <button onClick={handleLogout}>Logout</button>
      </nav>

      {/* ✅ Content Area - Renders Components Dynamically */}
      <div className={styles.contentArea}>
        {activePage === "home" && <FacultyHomeContent />}
        
        {activePage === "chatbot" && (
          <div className={styles.chatbotContainer}>
            <h2>AI Chatbot</h2>
            <div className={styles.chatMessages}>
              {messages.map((msg, index) => (
                <div key={index} className={msg.sender === "user" ? styles.userMessage : styles.botMessage}>
                  {msg.text}
                </div>
              ))}
              {botTyping && <div className={styles.typingAnimation}>Typing...</div>}
            </div>
            <div className={styles.chatInputContainer}>
              <input 
                type="text" 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                placeholder="Ask something..."
              />
              <button onClick={handleChatSubmit}>Send</button>
            </div>
          </div>
        )}

        {activePage === "edit-profile" && <EditProfile />}
      </div>
    </div>
  );
};

export default FacultyHome;
