import React from "react";
import styles from "../styles/Uploads.module.css"; 
import RequiredLabel from "./RequiredLabel"; 


const UploadsForm = ({ formData, setFormData }) => {
  const validateDriveLink = (link) => {
    const driveLinkPattern = /https?:\/\/(drive\.google\.com\/.*)/;
    return driveLinkPattern.test(link);
  };
  const handleInputChange = (e, fieldName) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      uploads: {
        ...prevFormData.uploads,
        [fieldName]: e.target.value, 
      },
    }));
  };

  return (
    <div className={styles["uploads-container"]}>
      <h2 className={styles["uploads-title"]}>Upload Documents</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["uploads-row"]}>
        <div className={styles["uploads-group"]}>
          <label className={styles["uploads-label"]}>{RequiredLabel("Aadhar Card Link", true)}</label>
          <input
            className={styles["uploads-input"]}
            type="text"
            placeholder="Enter Google Drive link"
            value={formData.uploads?.aadharCard || ""}
            onChange={(e) => handleInputChange(e, "aadharCard")}
          />
          {!validateDriveLink(formData.uploads?.aadharCard) && formData.uploads?.aadharCard && (
            <p className="error" style={{ color: 'red', fontSize: '12px' }}>Enter a valid Google Drive link.</p>
          )}
        </div>

        <div className={styles["uploads-group"]}>
          <label className={styles["uploads-label"]}>{RequiredLabel("PAN Card Link", true)}</label>
          <input
            className={styles["uploads-input"]}
            type="text"
            placeholder="Enter Google Drive link"
            value={formData.uploads?.panCard || ""}
            onChange={(e) => handleInputChange(e, "panCard")}
          />
          {!validateDriveLink(formData.uploads?.panCard) && formData.uploads?.panCard && (
            <p className="error" style={{ color: 'red', fontSize: '12px' }}>Enter a valid Google Drive link.</p>
          )}
        </div>
      </div>

      <div className={`${styles["uploads-group"]} ${styles["uploads-passport"]}`}>
        <label className={styles["uploads-label"]}>{RequiredLabel("Passport Size Photo Link", true)}</label>
        <input
          className={styles["passport"]}
          type="text"
          placeholder="Enter Google Drive link"
          value={formData.uploads?.passportPhoto || ""}
          onChange={(e) => handleInputChange(e, "passportPhoto")}
        />
        {!validateDriveLink(formData.uploads?.passportPhoto) && formData.uploads?.passportPhoto && (
          <p className="error" style={{ color: 'red', fontSize: '12px' }}>Enter a valid Google Drive link.</p>
        )}
      </div>
    </div>
  );
};

export default UploadsForm;
