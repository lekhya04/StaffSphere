import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "./button";
import styles from "../styles/Additional.module.css";
import btnstyles from "../styles/Edit.module.css";
import RequiredLabel from "./RequiredLabel"; 
import axios from "axios";


const EditAdditionalDetailsForm = () => {
  const [interestInput, setInterestInput] = useState("");
  const [errors,setErrors] = useState({});

  const validateDriveLink = (link) => {
    const driveLinkPattern = /https?:\/\/(drive\.google\.com\/.*)/;
    return driveLinkPattern.test(link);
  };
  const location = useLocation();
  const navigate = useNavigate();

  const facultyData = location.state || { additionalDetails: {} };
  const [formData, setFormData] = useState(facultyData);

  useEffect(() => {
    console.log("Received facultyData:", facultyData);
    if (facultyData.additionalDetails) {
      setFormData(facultyData);
    }
  }, [facultyData]);

  const handleInputChange = (section, index, field, value) => {
    setFormData((prev) => ({
      ...prev,
      additionalDetails: {
        ...prev.additionalDetails,
        [section]: prev.additionalDetails[section].map((item, i) =>
          i === index ? { ...item, [field]: value } : item
        ),
      },
    }));
    if (field.includes("Certificate") || field === "certificationLink") {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [field]: validateDriveLink(value) ? "" : "Enter a valid Google Drive link.",
      }));
    }
  };

  const handleAddItem = (section, newItem) => {
    setFormData((prev) => ({
      ...prev,
      additionalDetails: {
        ...prev.additionalDetails,
        [section]: [...prev.additionalDetails[section], newItem],
      },
    }));
  };

  const handleRemoveItem = (section, index) => {
    setFormData((prev) => ({
      ...prev,
      additionalDetails: {
        ...prev.additionalDetails,
        [section]: prev.additionalDetails[section].filter((_, i) => i !== index),
      },
    }));
  };

  const handleInterestKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      if (interestInput.trim() !== "") {
        setFormData((prev) => ({
          ...prev,
          additionalDetails: {
            ...prev.additionalDetails,
            areasOfInterest: [...prev.additionalDetails.areasOfInterest, interestInput.trim()],
          },
        }));
        setInterestInput(""); 
      }
    }
  };
  const handleUpdateAdditionalDetails = async () => {
    try {
      const updatedData = {
        additionalDetails: formData.additionalDetails,
      };

      console.log("🚀 Updating Additional Details:", updatedData);

      const response = await axios.post(
        "http://localhost:5000/api/faculty-home/update-profile",
        updatedData,
        { withCredentials: true }
      );

      if (response.data.success) {
        alert("Additional Details updated successfully!");
        navigate("/edit-profile", { state: response.data.updatedProfile });
      } else {
        alert("Failed to update additional details.");
      }
    } catch (error) {
      console.error("❌ Update failed:", error);
      alert("Error updating additional details. Try again.");
    }
  };

  return (
    <div className={styles["additional-form-container"]}>
      <h2 className={styles["additional-form-title"]}>Additional Details</h2>
      <p style={{ color: "red", fontSize: "14px" }}>Fields marked with * are required</p>
      <br></br>
      <div className={styles["additional-form-group"]}>
        <label>{RequiredLabel("Area Of Interest", true)}</label>
        <input
          type="text"
          className={styles["additional-input-field"]}
          placeholder="Enter and press Enter"
          value={interestInput}
          onChange={(e) => setInterestInput(e.target.value)}
          onKeyDown={handleInterestKeyDown}
        />
        <div className={styles["additional-interest-tags"]}>
          {formData.additionalDetails.areasOfInterest.map((interest, index) => (
            <span key={index} className={styles["additional-interest-tag"]}>
              {interest} <button className={styles["cross"]} onClick={() => handleRemoveItem("areasOfInterest", index)}>×</button>
            </span>
          ))}
        </div>
      </div>

      <div className={styles["additional-form-group"]}>
        <label>Competitive Exams (If Any)</label>
        {formData.additionalDetails.examList.map((exam, index) => (
          <div key={index} className={styles["additional-entry-container"]}>
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Exam Name"
              value={exam.name}
              onChange={(e) => handleInputChange("examList", index, "name", e.target.value)}
            />
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Google Drive Certificate Link"
              value={exam.examCertificate}
              onChange={(e) => handleInputChange("examList", index, "examCertificate", e.target.value)}
            />
            {errors.examCertificate && <p style={{ color: "red" }}>{errors.examCertificate}</p>}
            <Button className={styles["additional-remove-btn"]} onClick={() => handleRemoveItem("examList", index)}>- Remove</Button>
          </div>
        ))}
        <Button className={styles["additional-add-btn"]} onClick={() => handleAddItem("examList", { name: "", examCertificate: "" })}>
          + Add Exam
        </Button>
      </div>

      <div className={styles["additional-form-group"]}>
        <label>Certifications (If Any)</label>
        {formData.additionalDetails.certifications.map((cert, index) => (
          <div key={index} className={styles["additional-entry-container"]}>
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Certificate Name"
              value={cert.name}
              onChange={(e) => handleInputChange("certifications", index, "name", e.target.value)}
            />
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Provider"
              value={cert.provider}
              onChange={(e) => handleInputChange("certifications", index, "provider", e.target.value)}
            />
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Google Drive Certificate Link"
              value={cert.certificationLink}
              onChange={(e) => handleInputChange("certifications", index, "certificationLink", e.target.value)}
            />
            {errors.certificationLink && <p style={{ color: "red" }}>{errors.certificationLink}</p>}

            <Button className={styles["additional-remove-btn"]} onClick={() => handleRemoveItem("certifications", index)}>- Remove</Button>
          </div>
        ))}
        <Button className={styles["additional-add-btn"]} onClick={() => handleAddItem("certifications", { name: "", provider: "", certificate: "" })}>
          + Add Certification
        </Button>
      </div>

      <div className={styles["additional-form-group"]}>
        <label>Projects (If Any)</label>
        {formData.additionalDetails.projects.map((project, index) => (
          <div key={index} className={styles["additional-entry-container"]}>
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Project Name"
              value={project.name}
              onChange={(e) => handleInputChange("projects", index, "name", e.target.value)}
            />
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Domain"
              value={project.domain}
              onChange={(e) => handleInputChange("projects", index, "domain", e.target.value)}
            />
            <select
              className={styles["additional-input-field"]}
              value={project.status}
              onChange={(e) => handleInputChange("projects", index, "status", e.target.value)}
            >
              <option value="">Select Status</option>
              <option value="Completed">Completed</option>
              <option value="Ongoing">Ongoing</option>
            </select>
            <Button className={styles["additional-remove-btn"]} onClick={() => handleRemoveItem("projects", index)}>- Remove</Button>
          </div>
        ))}
        <Button className={styles["additional-add-btn"]} onClick={() => handleAddItem("projects", { name: "", domain: "", status: "" })}>
          + Add Project
        </Button>
      </div>

      <div className={styles["additional-form-group"]}>
        <label>Memberships (If Any)</label>
        {formData.additionalDetails.memberships.map((membership, index) => (
          <div key={index} className={styles["additional-entry-container"]}>
            <input
              type="text"
              className={styles["additional-input-field"]}
              placeholder="Membership Name"
              value={membership.name}
              onChange={(e) => handleInputChange("memberships", index, "name", e.target.value)}
            />
            <Button className={styles["additional-remove-btn"]} onClick={() => handleRemoveItem("memberships", index)}>- Remove</Button>
          </div>
        ))}
        <Button className={styles["additional-add-btn"]} onClick={() => handleAddItem("memberships", { name: "" })}>
          + Add Membership
        </Button>
      </div>
      <button 
        className={btnstyles["edit-backButton"]} 
        onClick={() => navigate("/edit-profile")} // Navigate back to Edit Profile page
      >
        🔙 Back
      </button>

      <button 
        className={btnstyles["edit-updateButton"]} 
        onClick={handleUpdateAdditionalDetails} // Call handleUpdate function
      >
        Update Additional Details
      </button>

    </div>
  );
};

export default EditAdditionalDetailsForm;
