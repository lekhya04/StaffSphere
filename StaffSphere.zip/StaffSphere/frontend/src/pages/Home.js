import React from "react";
import styles from "../styles/Home.module.css";

const images = [
  "/assets/c1.jpg",
  "/assets/c2.jpg",
  "/assets/c3.jpg",
  "/assets/c4.jpg",
  "/assets/c5.jpg",
  "/assets/c6.jpg",
  "/assets/c7.jpg",
  "/assets/c8.jpg",
  "/assets/c9.jpg",
  "/assets/c10.jpg",
  "/assets/c11.jpg",
];

const Home = () => {
  return (
    <div className={styles.homeContainer}>
      <div className={styles.slideshowWrapper}>
        {images.map((img, index) => (
          <div key={index} className={`${styles.slide} ${styles[`animation${index + 1}`]}`}>
            <img src={img} alt={`Slide ${index + 1}`} className={styles.slideImage} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
