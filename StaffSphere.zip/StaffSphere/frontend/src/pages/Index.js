import React, { useState, useEffect } from "react";
import { TubelightNavBar } from "../components/TubelightNavBar";
import "../styles/TubelightNavBar.css";
import styles from "../styles/Index.module.css";
import Home from "./Home";
import AdminLogin from "./AdminLogin";
import Register from "./RegistrationForm";
import About from "./About";
import Login from "./Login";

const SLIDES = [
  "/assets/c1.jpg",
  "/assets/c2.jpg",
  "/assets/c3.jpg",
  "/assets/c4.jpg",
  "/assets/c5.jpg",
  "/assets/c6.jpg",
  "/assets/c7.jpg",
  "/assets/c8.jpg",
  "/assets/c9.jpg",
  "/assets/c10.jpg",
  "/assets/c11.jpg",
];

const Index = () => {
  const [activePage, setActivePage] = useState("home");
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mainContent, setMainContent] = useState("slideshow");

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const renderPage = () => {
    switch (activePage) {
      case "admin":
        return <AdminLogin />;
      case "faculty":
        return <Login />;
      case "Register":
        return <Register />;
      case "About":
        return <About />;
      default:
        return null;
    }
  };

  const handleNavSelect = (tab) => {
    if (tab === "Admin") {
      setActivePage("admin");
      setMainContent("admin");
    } else if (tab === "Home") {
      setActivePage("home");
      setMainContent("slideshow");
    } else if (tab === "Faculty Login") {
      setActivePage("faculty");
      setMainContent("faculty");
    } else if (tab === "Register") {
      setActivePage("Register");
      setMainContent("slideshow");
    } else if (tab === "About") {
      setActivePage("About");
      setMainContent("slideshow");
    }
  };

  return (
    <div className={styles.indexContainer}>
      <TubelightNavBar onNavSelect={handleNavSelect} />
      <div className={styles.mainLayout}>
        {activePage === "Register" ? (
          <div className={styles.fullPageContent}>
            <Register />
          </div>
        ) : activePage === "About" ? (
          <div className={styles.fullPageContent}>
            <About />
          </div>
        ) : activePage === "admin" ? (
          <div className={styles.fullPageContent}>
            <AdminLogin />
          </div>
        ) : activePage === "faculty" ? (
          <div className={styles.fullPageContent}>
            <Login />
          </div>
        ) : (
          /* Split content layout for home page */
          <div className={styles.splitContent}>
            <div className={styles.leftContent}>
              <div className={styles.slideshowContainer}>
                <div className={styles.slideshowWrapper}>
                  {SLIDES.map((slide, index) => (
                    <div
                      key={index}
                      className={styles.slide}
                      style={{
                        opacity: index === currentSlide ? 1 : 0,
                        transition: "opacity 0.5s ease-in-out",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                      }}
                    >
                      <img src={slide} alt={`Slide ${index + 1}`} />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right side content with logo */}
            <div className={styles.rightContent}>
              <img
                src="/assets/SS.jpg"
                alt="StaffSphere"
                className={styles.mainLogo}
              />
              <div className={styles.logoText} style={{ textAlign: "center", fontSize: "1.5rem", width: "100%", display: "block" }}>
                StaffSphere Portal
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
