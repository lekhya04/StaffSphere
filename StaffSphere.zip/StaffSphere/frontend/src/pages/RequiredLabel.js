import React from "react";

export const RequiredLabel = (label, isRequired) => (
    <>
      {label} {isRequired && <span style={{ color: "red" }}>*</span>}
    </>
  );
export default RequiredLabel;
