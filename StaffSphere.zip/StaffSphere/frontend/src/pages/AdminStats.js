import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/AdminStats.module.css";
import { Bar, Pie, Doughnut, Line } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, LineElement, PointElement } from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, LineElement, PointElement);


const AdminStats = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [facultyData, setFacultyData] = useState({});

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/admin/faculty-stats")
      .then((response) => {
        setFacultyData(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching faculty statistics:", error);
        setLoading(false);
      });
  }, []);

  if (loading) return <p className={styles.loadingText}>Loading statistics...</p>;

  // ✅ Extracting Data from Backend Response
  const {
    subjectFacultyCount,
    genderEducation,
    certificationMembership,
    facultyCountPerYear,
    phdGuidanceCount,
    genderDist,
    maritalDist,
    casteDist,
    phdStatus,
    facultyExperienceDist,
    examDist,
    experienceDist, 
    membershipDist,
    certificationDist,
    projectsDist,
  } = facultyData;

  // ✅ Chart Data Configurations
  const subjectFacultyChart = {
    labels: Object.keys(subjectFacultyCount || {}),
    datasets: [{ label: "Faculty per Subject", data: Object.values(subjectFacultyCount || {}), backgroundColor: "#3498db" }],
  };
  const experienceFaculty = {
    labels: [
      "Teaching Only",
      "Research Only",
      "Industry Only",
      "Teaching & Research",
      "Teaching & Industry",
      "Research & Industry",
      "All Three",
      "None"
    ],
    datasets: [
      {
        label: "Faculty Count",
        data: [
          experienceDist?.OnlyTeaching || 0,
          experienceDist?.OnlyResearch || 0,
          experienceDist?.OnlyIndustry || 0,
          experienceDist?.TeachingResearch || 0,
          experienceDist?.TeachingIndustry || 0,
          experienceDist?.ResearchIndustry || 0,
          experienceDist?.AllThree || 0,
          experienceDist?.None || 0
        ],
        backgroundColor: [
          "#3498db", // Teaching Only - Blue
          "#e74c3c", // Research Only - Red
          "#f1c40f", // Industry Only - Yellow
          "#9b59b6", // Teaching & Research - Purple
          "#2ecc71", // Teaching & Industry - Green
          "#e67e22", // Research & Industry - Orange
          "#1abc9c", // All Three - Teal
          "#95a5a6"  // None - Gray
        ]
      }
    ]
  };
  

  const genderEducationChart = {
    labels: ["UG", "PG", "PhD"],
    datasets: [
      { label: "Male", data: Object.values(genderEducation).map(d => d.Male), backgroundColor: "#2980b9" },
      { label: "Female", data: Object.values(genderEducation).map(d => d.Female), backgroundColor: "#e74c3c" }
    ],
  };

  const certMembershipData = {
    labels: ["Only Certifications", "Only Memberships", "Both", "None"],
    datasets: [
      {
        data: [
          certificationMembership.OnlyCertifications,
          certificationMembership.OnlyMemberships,
          certificationMembership.Both,
          certificationMembership.None
        ],
        backgroundColor: ["#3498db", "#e74c3c", "#2ecc71", "#95a5a6"]
      }
    ]
  };
  const facultyCountChart = {
    labels: Object.keys(facultyCountPerYear || {}),
    datasets: [{ label: "Faculty Joined", data: Object.values(facultyCountPerYear || {}), backgroundColor: "#9b59b6" }],
  };

  const phdGuidanceChart = {
    labels: ["With Guide", "Without Guide"],
    datasets: [{ data: Object.values(phdGuidanceCount || {}), backgroundColor: ["#1abc9c", "#e74c3c"] }],
  };

  const genderChart = {
    labels: Object.keys(genderDist || {}),
    datasets: [{ data: Object.values(genderDist || {}), backgroundColor: ["#3498db", "#e74c3c"] }],
  };
  
  const maritalChart = {
    labels: Object.keys(maritalDist || {}),
    datasets: [{ data: Object.values(maritalDist || {}), backgroundColor: ["#16a085", "#f39c12"] }],
  };

  const casteChart = {
    labels: Object.keys(casteDist || {}),
    datasets: [{ data: Object.values(casteDist || {}), backgroundColor: ["#2ecc71", "#e74c3c", "#f1c40f"] }],
  };

  const phdStatusChart = {
    labels: Object.keys(phdStatus || {}),
    datasets: [{ data: Object.values(phdStatus || {}), backgroundColor: ["#8e44ad", "#2c3e50", "#e67e22"] }],
  };

  const experienceChart = {
    labels: Object.keys(facultyExperienceDist || {}),
    datasets: [{ label: "Experience", data: Object.values(facultyExperienceDist || {}), backgroundColor: "#f39c12" }],
  };

  const examChart = {
    labels: Object.keys(examDist || {}),
    datasets: [{ data: Object.values(examDist || {}), backgroundColor: "#27ae60" }],
  };

  const membershipChart = {
    labels: Object.keys(membershipDist || {}),
    datasets: [{ data: Object.values(membershipDist || {}), backgroundColor: "#d35400" }],
  };

  const certificationChart = {
    labels: ["With Certifications", "No Certifications"],
    datasets: [{ data: Object.values(certificationDist || {}), backgroundColor: ["#2980b9", "#c0392b"] }],
  };

  const projectsChart = {
    labels: Object.keys(projectsDist || {}),
    datasets: [{ data: Object.values(projectsDist || {}), backgroundColor: ["#16a085", "#f39c12", "#e74c3c"] }],
  };

  return (
    <div className={styles.statsContainer}>
      {/* Header Section */}
      <div className={styles.header}>
        <h1>📊 Faculty Statistics Dashboard</h1>
        <button className={styles.backButton} onClick={() => navigate("/admin")}>← Back to Admin</button>
      </div>

      {/* Charts Grid */}
      <div className={styles.chartsGrid}>
        <div className={styles.chartCard}><h3>📚 Faculty per Subject</h3><Bar data={subjectFacultyChart} /></div>
        <div className={styles.chartCard}><h3>🎓 Gender Education Distribution</h3><Bar data={genderEducationChart} /></div>
        <div className={styles.chartCard}><h3>📜 Certifications vs Memberships</h3><Doughnut data={certMembershipData} /></div>
        <div className={styles.chartCard}><h3>📅 Faculty Joining Trends</h3><Line data={facultyCountChart} /></div>
        <div className={styles.chartCard}><h3>🎓 PhD Guidance</h3><Pie data={phdGuidanceChart} /></div>
        <div className={styles.chartCard}><h3>🚻 Gender Distribution</h3><Pie data={genderChart} /></div>
        <div className={styles.chartCard}><h3>💍 Marital Status</h3><Doughnut data={maritalChart} /></div>
        <div className={styles.chartCard}><h3>🌍 Caste Distribution</h3><Bar data={casteChart} /></div>
        <div className={styles.chartCard}><h3>🎓 PhD Status</h3><Bar data={phdStatusChart} /></div>
        <div className={styles.chartCard}><h3>📈 Faculty Teaching Experience</h3><Line data={experienceChart} /></div>
        <div className={styles.chartCard}><h3>📚 Exam Participation</h3><Bar data={examChart} /></div>
        <div className={styles.chartCard}><h3>📜 Faculty Memberships</h3><Bar data={membershipChart} /></div> 
        <div className={styles.chartCard}>
          <h3>📊 Faculty Experience Distribution</h3>
          <Bar data={experienceFaculty} />
        </div>
        <div className={styles.chartCard}><h3>📜 Certifications</h3><Doughnut data={certificationChart} /></div>
        <div className={styles.chartCard}><h3>📂 Project Status</h3><Pie data={projectsChart} /></div>
      </div>
    </div>
  );
};

export default AdminStats;
