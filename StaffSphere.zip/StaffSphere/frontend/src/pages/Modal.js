import React from "react";
import styles from "../styles/Modal.module.css";

const Modal = ({ isOpen, onClose, children }) => {
  if (!isOpen) return null; // If modal is not open, don't render anything

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modalBox} onClick={(e) => e.stopPropagation()}>
        {children} {/* The modal content will be passed from Admin.js */}
      </div>
    </div>
  );
};

export default Modal;
