import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Index from "./pages/Index"; 
import RegistrationForm from "./pages/RegistrationForm"; 
import Home from "./pages/Home";
import Login from "./pages/Login";
import Admin from "./pages/Admin";
import AdminLogin from "./pages/AdminLogin"; 
import About from "./pages/About";
import ThankYou from "./pages/ThankYou";
import FacultyHome from "./pages/FacultyHome";
import FacultyHomeContent from "./pages/FacultyHomeContent";
import ForgotPassword from "./pages/ForgotPassword";
import EditProfile from "./pages/EditProfile";  
import EditPersonalInfo from "./pages/EditPersonalInfo"; 
import EditQualificationInfo from "./pages/EditQualificationInfo";
import EditExperienceInfo from "./pages/EditExperienceInfo";
import EditAdditionalInfo from "./pages/EditAdditionalInfo";
import EditUploads from "./pages/EditUploads";
import AdminStats from "./pages/AdminStats";
import "./styles/Register.css";
import "./styles/global.css";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/home" element={<Home />} />
        <Route path="/register" element={<RegistrationForm />} />
        <Route path="/login" element={<Login />} /> 
        <Route path="/admin" element={<Admin/>}/>
        <Route path="/admin/stats" element={<AdminStats/>}/>
        <Route path="/admin-login" element={<AdminLogin />} /> 
        <Route path="/about" element={<About />} /> 
        <Route path="/thank-you" element={<ThankYou />} /> 
        <Route path="/faculty-home" element={<FacultyHome />} />
        <Route path="/faculty-home-content" element={<FacultyHomeContent />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/edit-profile" element={<EditProfile />} />
        <Route path="/edit-profile/edit-personal-info" element={<EditPersonalInfo />} />
        <Route path="/edit-profile/edit-qualification-info" element={<EditQualificationInfo />} />
        <Route path="/edit-profile/edit-experience-info" element={<EditExperienceInfo />} />
        <Route path="/edit-profile/edit-additional-info" element={<EditAdditionalInfo />} />
        <Route path="/edit-profile/edit-uploads" element={<EditUploads />} />
      </Routes>
    </Router>
  );
}

export default App;
