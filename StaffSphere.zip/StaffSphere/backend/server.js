import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import registrationRoutes from "./routes/registrationRoutes.js"; 
import adminRoutes from "./routes/adminRoutes.js"; 
import authRoutes from "./routes/authRoutes.js";
import passwordRoutes from "./routes/passwordRoutes.js";
import adminAuthRoutes from "./routes/adminAuthRoutes.js"; 
import facultyHomeRoutes from "./routes/facultyHomeRoutes.js";

dotenv.config(); 

const app = express();

app.use(cors({
    origin: "http://localhost:3000", 
    credentials: true, // 
}));
app.use(express.json()); 
app.use(express.urlencoded({ extended: true })); 
app.use(cookieParser());

mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log("MongoDB Connected Successfully"))
.catch((error) => console.error("MongoDB Connection Error:", error));

app.use("/api/registration", registrationRoutes); 
app.use("/api/admin", adminRoutes); 
app.use("/api/admin/auth", adminAuthRoutes); 
app.use("/api/auth", authRoutes);
app.use("/api/password", passwordRoutes);
app.use("/api/faculty-home", facultyHomeRoutes);


app.get("/", (req, res) => {
    res.send("Server is running!");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
