import sys
import json
from pymongo import MongoClient
import ollama
try:
    client = MongoClient("mongodb://localhost:27017/")
    db = client["StaffDB"]  
    collection = db["registrations"]
except Exception as e:
    print(json.dumps({"error": f"MongoDB connection failed: {str(e)}"}))
    sys.exit(1)
try:
    user_query = sys.argv[1]  
except Exception as e:
    print(json.dumps({"error": f"Invalid input JSON: {str(e)}"}))
    sys.exit(1)
print(f"📩 User Query Received: {user_query}", file=sys.stderr)
faculty_list = []
try:
    all_faculty_cursor = collection.find({}, {"_id": 0, "personalInfo.facultyID": 1, "personalInfo.name": 1, "personalInfo.personalPhone": 1, "additionalDetails.areasOfInterest": 1})
    for faculty in all_faculty_cursor:
        if "additionalDetails" in faculty and "areasOfInterest" in faculty["additionalDetails"]:
            faculty_list.append({
                "facultyID": faculty["personalInfo"]["facultyID"],
                "name": faculty["personalInfo"]["name"],
                "phone": faculty["personalInfo"]["personalPhone"],
                "areasOfInterest": faculty["additionalDetails"]["areasOfInterest"]
            })
except Exception as e:
    print(json.dumps({"error": f"MongoDB query failed: {str(e)}"}))
    sys.exit(1)
if not faculty_list:
    print(json.dumps({"error": "No faculty data found in database."}))
    sys.exit(1)
matching_faculty = []
try:
    for faculty in faculty_list:
        for interest in faculty["areasOfInterest"]:
            prompt = f"A user is searching for faculty interested in '{user_query}'. Does '{interest}' match their query? Reply only 'yes' or 'no'."
            response = ollama.chat(model="mistral", messages=[{"role": "user", "content": prompt}])
            similarity_result = response["message"]["content"].strip().lower()
            print(f"🔍 Ollama Response: '{user_query}' vs '{interest}' → {similarity_result}", file=sys.stderr)
            if similarity_result == "yes":
                matching_faculty.append({
                    "facultyID": faculty["facultyID"],
                    "name": faculty["name"],
                    "phone": faculty["phone"],  
                    "matchedInterest": interest
                })
                break  
except Exception as e:
    print(json.dumps({"error": f"Ollama processing failed: {str(e)}"}))
    sys.exit(1)
print(json.dumps({"matching_faculty": matching_faculty}))