import express from "express";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import cookieParser from "cookie-parser"; 
import Registration from "../models/registrationModel.js"; 

dotenv.config(); 
const router = express.Router();
router.use(cookieParser()); 

router.post("/login", async (req, res) => {
    console.log("Received login request:", req.body);

    const { facultyID, password } = req.body;
    if (!facultyID || !password) {
        return res.status(400).json({ message: "Faculty ID and password are required" });
    }

    try {
        const faculty = await Registration.findOne({ "personalInfo.facultyID": facultyID });

        if (!faculty) {
            return res.status(404).json({ message: "User not found" });
        }

        console.log("User found:", faculty.personalInfo.name);
        console.log("Stored password in DB:", faculty.password);
        console.log("Entered password:", password);

        let isMatch = false;

        if (faculty.password.startsWith("$2b$")) {  
            console.log("Password is already hashed. Validating...");
            isMatch = await bcrypt.compare(password, faculty.password);
        } else {
            console.log("Plain text password detected. Hashing it now...");
            
            const hashedPassword = await bcrypt.hash(password, 10);
            await Registration.updateOne({ "personalInfo.facultyID": facultyID }, { password: hashedPassword });
            faculty.password = hashedPassword;
            
            isMatch = true;
        }

        if (!isMatch) {
            console.log("Incorrect password");
            return res.status(401).json({ message: "Incorrect password" });
        }

        const token = jwt.sign(
            { facultyID: faculty.personalInfo.facultyID, name: faculty.personalInfo.name },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );
        res.cookie("facultyToken", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "strict",
            maxAge: 3600000, 
        });

        res.json({ message: "Login successful" });

    } catch (error) {
        console.error("Login error:", error.message);
        res.status(500).json({ message: "Something went wrong, please try again later." });
    }
});

router.post("/logout", (req, res) => {
    res.clearCookie("facultyToken");
    res.json({ success: true, message: "Logged out successfully" });
});

 export const verifyFaculty = (req, res, next) => {
    const token = req.cookies.facultyToken;
    if (!token) {
        return res.status(403).json({ message: "Unauthorized: No token provided" });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(403).json({ message: "Unauthorized: Invalid token" });
        req.faculty = decoded;
        next();
    });
};

router.get("/dashboard", verifyFaculty, async (req, res) => {
    try {
        const faculty = await Registration.findOne({ "personalInfo.facultyID": req.faculty.facultyID });

        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }

        console.log("Dashboard API Response:", faculty); 
        res.json({ 
            name: faculty.personalInfo.name, 
            editRequestStatus: faculty.editRequestStatus 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

export default router;
