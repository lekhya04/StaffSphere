import express from "express";
import Registration from "../models/registrationModel.js";
import RevealedFaculty from "../models/revealedFacultyModel.js";
import ExcelJS from "exceljs";
const router = express.Router();
router.get("/faculty-stats", async (req, res) => {
  try {
    const activeFaculty = await Registration.find();
    const allFaculty = [...activeFaculty];
    if (!allFaculty.length) {
      return res.status(404).json({ message: "No faculty data found." });
    }
    const subjectFacultyCount = {};
    allFaculty.forEach(faculty => {
      if (faculty.experienceInfo?.teachingExp === "yes") {  
        const subjects = faculty.experienceInfo?.teachingSubjects || [];
        subjects.forEach(sub => {
          if (sub.subject !== "NA") {  
            subjectFacultyCount[sub.subject] = (subjectFacultyCount[sub.subject] || 0) + 1;
          }
        });
      }
    });
    const genderEducation = { 
      UG: { Male: 0, Female: 0}, 
      PG: { Male: 0, Female: 0}, 
      PhD: { Male: 0, Female: 0} 
    };
    allFaculty.forEach(fac => {
      const level = fac.qualificationInfo.educationLevel;  
      const phdStatus = fac.qualificationInfo.phdStatus;  
      const gender = fac.personalInfo.gender;  
      if (level && genderEducation[level]) {
        genderEducation[level][gender] = (genderEducation[level][gender] || 0) + 1;
      }
      if (phdStatus === "yes") {
        genderEducation["PhD"][gender] = (genderEducation["PhD"][gender] || 0) + 1;
      }
    });  
    const certificationMembership = { OnlyCertifications: 0, OnlyMemberships: 0, Both: 0, None: 0 };
    allFaculty.forEach(fac => {
      const hasCertifications = fac.additionalDetails?.certifications?.some(cert => cert.provider && cert.provider.trim().toLowerCase() !== "NA");
      const hasMemberships = fac.additionalDetails?.memberships?.some(mem => mem.name && mem.name.trim().toLowerCase() !== "NA");
      if (hasCertifications && hasMemberships) {
        certificationMembership.Both++;
      } else if (hasCertifications) {
        certificationMembership.OnlyCertifications++;
      } else if (hasMemberships) {
        certificationMembership.OnlyMemberships++;
      } else {
        certificationMembership.None++;
      }
    });
    const joiningYears = allFaculty.map(fac => {
      const rawDate = fac.experienceInfo?.dateOfJoining || "";
      const extractedYear = rawDate.split(" / ")[0].split("-")[0]; // Extract year from date
      return extractedYear;
    }).filter(year => year && !isNaN(year)).map(year => parseInt(year)); 
    if (!joiningYears.length) {
      return {};
    }
    const minYear = Math.min(...joiningYears);
    const maxYear = Math.max(...joiningYears);
    const facultyCountPerYear = {};
    for (let year = minYear; year <= maxYear; year++) {
      facultyCountPerYear[year] = 0;
    }
    joiningYears.forEach(year => {
      facultyCountPerYear[year] += 1;
    });
    const phdGuidanceCount = { WithGuide: 0, WithoutGuide: 0 };
    allFaculty.forEach(fac => {
      if (fac.qualificationInfo?.phdStatus?.toLowerCase() === "yes") {  
        const hasGuide = fac.qualificationInfo?.phdList?.some(phd => 
          phd.guideName && phd.guideName.trim().toLowerCase() !== "NA" && phd.guideName.trim() !== ""
        );
        if (hasGuide) {
          phdGuidanceCount.WithGuide += 1; 
        } else {
          phdGuidanceCount.WithoutGuide += 1; 
        }
      }
    });
    const genderDist = { Male: 0, Female: 0};
    const maritalDist = { Married: 0, Unmarried: 0};
    const casteDist = { General: 0, OBC: 0, SC: 0, ST: 0, Other: 0 };
    allFaculty.forEach(fac => {
      if (fac.personalInfo.gender) genderDist[fac.personalInfo.gender]++;
      if (fac.personalInfo.maritalStatus) maritalDist[fac.personalInfo.maritalStatus]++;
      if (fac.personalInfo.caste) casteDist[fac.personalInfo.caste]++;
    });
    const phdStatus = { Completed: 0, NotCompleted: 0, NotPursuing: 0 };
    const facultyExperienceDist = { "0-5": 0, "6-10": 0, "11-15": 0, "16+": 0 };
    allFaculty.forEach(fac => {
      if (fac.qualificationInfo?.phdList?.length > 0) {
        const hasCompletedPhD = fac.qualificationInfo.phdList.some(phd => phd.status === "completed");
        if (hasCompletedPhD) {
          phdStatus.Completed++;
        } else {
          phdStatus.NotCompleted++;
        }
      } else {
        phdStatus.NotPursuing++; 
      }
      const expYears = parseInt(fac.experienceInfo.teachingDuration) || 0;
      if (expYears <= 5) facultyExperienceDist["0-5"]++;
      else if (expYears <= 10) facultyExperienceDist["6-10"]++;
      else if (expYears <= 15) facultyExperienceDist["11-15"]++;
      else facultyExperienceDist["16+"]++;
    });
    const experienceDist = {
      OnlyTeaching: 0,
      OnlyResearch: 0,
      OnlyIndustry: 0,
      TeachingResearch: 0,
      TeachingIndustry: 0,
      ResearchIndustry: 0,
      AllThree: 0,
      None: 0
    };
    allFaculty.forEach(fac => {
      const hasTeaching = fac.experienceInfo?.teachingExp === "yes";
      const hasResearch = fac.experienceInfo?.researchExp === "yes";
      const hasIndustry = fac.experienceInfo?.industryExp === "yes";
      if (hasTeaching && hasResearch && hasIndustry) {
        experienceDist.AllThree++;
      } else if (hasTeaching && hasResearch) {
        experienceDist.TeachingResearch++;
      } else if (hasTeaching && hasIndustry) {
        experienceDist.TeachingIndustry++;
      } else if (hasResearch && hasIndustry) {
        experienceDist.ResearchIndustry++;
      } else if (hasTeaching) {
        experienceDist.OnlyTeaching++;
      } else if (hasResearch) {
        experienceDist.OnlyResearch++;
      } else if (hasIndustry) {
        experienceDist.OnlyIndustry++;
      } else {
        experienceDist.None++;
      }
    });
    const examDist = {}; 
    const membershipDist = {}; 
    const certificationDist = { WithCertifications: 0, NoCertifications: 0 }; 
    const projectsDist = { Completed: 0, Ongoing: 0, NoProjects: 0 };
    allFaculty.forEach(fac => {
      fac.additionalDetails?.projects?.forEach(proj => {
        if (proj.status === "Completed") {
          projectsDist.Completed++;
        } else if (proj.status === "Ongoing") {
          projectsDist.Ongoing++;
        } else if (proj.status === "NA") {
          projectsDist.NoProjects++;
        }
      });
      if (fac.additionalDetails?.examList?.length > 0) {
        fac.additionalDetails.examList.forEach(exam => {
          if(exam.name!=="NA"){
            examDist[exam.name] = (examDist[exam.name] || 0) + 1;
          }
        });
      }
      if (fac.additionalDetails?.memberships?.length > 0) {
        fac.additionalDetails.memberships.forEach(mem => {
          if (mem.name !== "NA") {  
            membershipDist[mem.name] = (membershipDist[mem.name] || 0) + 1;
          }
        });
      }
      if (fac.additionalDetails?.certifications?.length > 0) {
        certificationDist.WithCertifications++;
      } else {
        certificationDist.NoCertifications++;
      }
    });
    res.json({
      subjectFacultyCount,
      genderEducation,
      certificationMembership,
      facultyCountPerYear,
      phdGuidanceCount,
      genderDist,
      maritalDist,
      casteDist,
      phdStatus,
      facultyExperienceDist,
      experienceDist,
      examDist,
      certificationDist,
      projectsDist,
      membershipDist,
    });
  } catch (error) {
    console.error("Error fetching faculty stats:", error);
    res.status(500).json({ message: "Server error while fetching faculty stats." });
  }
});
router.post("/chart-data", async (req, res) => {
  try {
    const { startDate, endDate, filters } = req.body;
    if (!startDate || !endDate || !filters.length) {
      console.log("Invalid Request Data:", { startDate, endDate, filters });
      return res.status(400).json({ message: "Invalid request. Provide dates and filters." });
    }
    let chartData = {};
    for (const filter of filters) {
      switch (filter) {
        case "phd":
          chartData["PhD"] = await getPhDCounts(startDate, endDate);
          break;
        case "teaching":
          chartData["Teaching Experience"] = await getTeachingCounts(startDate, endDate);
          break;
        case "research":
          chartData["Research Experience"] = await getResearchCounts(startDate, endDate);
          break;
        case "industry":
          chartData["Industry Experience"] = await getIndustryCounts(startDate, endDate);
          break;
        case "projects":
          chartData["Projects Worked"] = await getProjectsCounts(startDate, endDate);
          break;
        case "competitiveExams":
          chartData["Competitive Exams"] = await getExamCounts(startDate, endDate);
          break;
        case "certifications":
          chartData["Certifications"] = await getCertificationCounts(startDate, endDate);
          break;
        case "memberships":
          chartData["Memberships"] = await getMembershipCounts(startDate, endDate);
          break;
        case "dateOfJoining":
          chartData["Date of Joining"] = await getJoiningYearCounts(startDate, endDate);          
          break;
        default:
          console.log(`Unknown filter: ${filter}`);
      }
    }
    console.log("Final Chart Data Response:", JSON.stringify(chartData, null, 2));
    res.json(chartData);
  } catch (error) {
    console.error("Error fetching chart data:", error);
    res.status(500).json({ message: "Server error while fetching chart data." });
  }
});
const getFilteredFaculty = async (startDate, endDate) => {
  console.log(`Filtering faculty between ${startDate} and ${endDate}`);
  const allFaculty = await Registration.find({});
  const allRevealedFaculty = await RevealedFaculty.find({});
  const cleanFacultyData = (facultyList) => {
    return facultyList.filter((faculty) => {
      const rawDate = faculty.experienceInfo?.dateOfJoining || "";
      const extractedDate = rawDate.split(" / ")[0]; // Extract only the actual date
      const formattedDate = new Date(extractedDate); // Convert to Date object
      if (isNaN(formattedDate)) {
        console.log(`Invalid Date for: ${faculty.personalInfo.name} -> ${rawDate}`);
      }
      return formattedDate >= new Date(startDate) && formattedDate <= new Date(endDate);
    });
  };
  const filteredActiveFaculty = cleanFacultyData(allFaculty);
  const filteredRevealedFaculty = cleanFacultyData(allRevealedFaculty);
  return { filteredActiveFaculty, filteredRevealedFaculty };
};
const getPhDCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  // ✅ Now query MongoDB with only the filtered faculty
  const phdActive = filteredActiveFaculty.filter(fac => fac.qualificationInfo?.phdStatus === "yes").length;
  const phdRevealed = filteredRevealedFaculty.filter(fac => fac.qualificationInfo?.phdStatus === "yes").length;
  const noPhD = filteredActiveFaculty.filter(fac => fac.qualificationInfo?.phdStatus === "no").length;
  return { Active: phdActive, Revealed: phdRevealed, "No PhD": noPhD };
};
const getTeachingCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const teachingActive = filteredActiveFaculty.filter(fac => fac.experienceInfo.teachingExp?.toLowerCase() === "yes").length;
  const teachingRevealed = filteredRevealedFaculty.filter(fac => fac.experienceInfo.teachingExp?.toLowerCase() === "yes").length;
  const noTeaching = filteredActiveFaculty.filter(fac => fac.experienceInfo.teachingExp?.toLowerCase() === "no").length;
  return {
    Active: teachingActive,
    Revealed: teachingRevealed,
    "No Teaching": noTeaching
  };
};
const getResearchCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const researchActive = filteredActiveFaculty.filter(fac => fac.experienceInfo.researchExp === "yes").length;
  const researchRevealed = filteredRevealedFaculty.filter(fac => fac.experienceInfo.researchExp === "yes").length;
  const noResearch = filteredActiveFaculty.filter(fac => fac.experienceInfo.researchExp === "no").length;
  return { Active: researchActive, Revealed: researchRevealed, "No Research": noResearch };
};
const getIndustryCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const industryActive = filteredActiveFaculty.filter(fac => fac.experienceInfo.industryExp === "yes").length;
  const industryRevealed = filteredRevealedFaculty.filter(fac => fac.experienceInfo.industryExp === "yes").length;
  const noIndustry = filteredActiveFaculty.filter(fac => fac.experienceInfo.industryExp === "no").length;
  return { Active: industryActive, Revealed: industryRevealed, "No Industry": noIndustry };
};
const getProjectsCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const projectActive = filteredActiveFaculty.filter(fac => fac.additionalDetails?.projects?.length > 0).length;
  const projectRevealed = filteredRevealedFaculty.filter(fac => fac.additionalDetails?.projects?.length > 0).length;
  const noProject = filteredActiveFaculty.filter(fac => !fac.additionalDetails?.projects?.length).length;
  return {
    "Active (With Projects)": projectActive,
    "Revealed (With Projects)": projectRevealed,
    "No Projects": noProject,
  };
};
const getExamCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const examActive = filteredActiveFaculty.filter(fac => fac.additionalDetails?.examList?.length > 0).length;
  const examRevealed = filteredRevealedFaculty.filter(fac => fac.additionalDetails?.examList?.length > 0).length;
  const noExam = filteredActiveFaculty.filter(fac => !fac.additionalDetails?.examList?.length).length;
  return {
    "Active (With Exams)": examActive,
    "Revealed (With Exams)": examRevealed,
    "No Exams": noExam,
  };
};
const getCertificationCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const certActive = filteredActiveFaculty.filter(fac => fac.additionalDetails?.certifications?.length > 0).length;
  const certRevealed = filteredRevealedFaculty.filter(fac => fac.additionalDetails?.certifications?.length > 0).length;
  const noCertifications = filteredActiveFaculty.filter(fac => !fac.additionalDetails?.certifications?.length).length;
  return {
    "Active (With Certifications)": certActive,
    "Revealed (With Certifications)": certRevealed,
    "No Certifications": noCertifications,
  };
};
const getMembershipCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const membershipActive = filteredActiveFaculty.filter(fac => fac.additionalDetails?.memberships?.length > 0).length;
  const membershipRevealed = filteredRevealedFaculty.filter(fac => fac.additionalDetails?.memberships?.length > 0).length;
  const noMemberships = filteredActiveFaculty.filter(fac => !fac.additionalDetails?.memberships?.length).length;
  return {
    "Active (With Memberships)": membershipActive,
    "Revealed (With Memberships)": membershipRevealed,
    "No Memberships": noMemberships,
  };
};
const getJoiningYearCounts = async (startDate, endDate) => {
  const { filteredActiveFaculty, filteredRevealedFaculty } = await getFilteredFaculty(startDate, endDate);
  const getYear = (faculty) => {
    const rawDate = faculty.experienceInfo?.dateOfJoining || "";
    return rawDate.split(" / ")[0].slice(0, 4); 
  };
  let yearCounts = {};
  filteredActiveFaculty.forEach((fac) => {
    const year = getYear(fac);
    if (year) yearCounts[year] = (yearCounts[year] || 0) + 1;
  });
  filteredRevealedFaculty.forEach((fac) => {
    const year = getYear(fac);
    if (year) yearCounts[year] = (yearCounts[year] || 0) + 1;
  });
  console.log("📊 Joining Year Distribution:", yearCounts);
  return yearCounts; 
};
router.post("/reveal-faculty", async (req, res) => {
  try {
    const { facultyID } = req.body;
    if (!facultyID) {
      return res.status(400).json({ message: "Faculty ID is required" });
    }
    const faculty = await Registration.findOne({ "personalInfo.facultyID": facultyID });
    if (!faculty) {
      return res.status(404).json({ message: "Faculty not found" });
    }
    faculty.experienceInfo.dateOfReveal = new Date().toISOString().slice(0, 10); // YYYY-MM-DD format
    const revealedFaculty = new RevealedFaculty({
      personalInfo: faculty.personalInfo,
      qualificationInfo: faculty.qualificationInfo,
      experienceInfo: faculty.experienceInfo,
      additionalDetails: faculty.additionalDetails,
      uploads: faculty.uploads,
      password: faculty.password, 
    });
    await revealedFaculty.save();
    await Registration.deleteOne({ "personalInfo.facultyID": facultyID });
    res.json({ message: `Faculty ${facultyID} has been releaved successfully.` });
  } catch (error) {
    console.error("Error releaving faculty:", error);
    res.status(500).json({ message: "An error occurred. Please try again later." });
  }
});
router.get("/edit-requests", async (req, res) => {
  try {
    const editRequests = await Registration.find({ editRequestStatus: "Pending" }, "personalInfo.name personalInfo.facultyID");
    res.json({ requests: editRequests.map(faculty => ({ name: faculty.personalInfo.name, facultyID: faculty.personalInfo.facultyID })) });
  } catch (error) {
    console.error("🔥 Error fetching edit requests:", error);
    res.status(500).json({ message: "Error fetching edit requests." });
  }
});
router.post("/approve-edit", async (req, res) => {
  try {
      const { facultyID } = req.body;
      if (!facultyID) {
          return res.status(400).json({ success: false, message: "Faculty ID is required." });
      }
      const faculty = await Registration.findOne({ "personalInfo.facultyID": facultyID });
      if (!faculty) {
          return res.status(404).json({ success: false, message: "Faculty not found." });
      }
      faculty.editRequestStatus = "Approved";
      await faculty.save();
      res.json({ success: true, message: "Edit request approved." });
  } catch (error) {
      console.error("Error approving edit request:", error);
      res.status(500).json({ success: false, message: "Error approving edit request." });
  }
});
router.post("/decline-edit", async (req, res) => {
  try {
      const { facultyID } = req.body;
      if (!facultyID) {
          return res.status(400).json({ success: false, message: "Faculty ID is required." });
      }
      const faculty = await Registration.findOne({ "personalInfo.facultyID": facultyID });
      if (!faculty) {
          return res.status(404).json({ success: false, message: "Faculty not found." });
      }
      faculty.editRequestStatus = "None";
      await faculty.save();
      res.json({ success: true, message: "Edit request declined." });
  } catch (error) {
      console.error("Error declining edit request:", error);
      res.status(500).json({ success: false, message: "Error declining edit request." });
  }
});
router.post("/export", async (req, res) => {
  try {
    const { startDate, endDate, filters, subFilters } = req.body;
    let query = {};
    if (filters.includes("phd")) query["qualificationInfo.phdStatus"] = "yes";
    if (filters.includes("teaching")) query["experienceInfo.teachingExp"] = "yes";
    if (filters.includes("research")) query["experienceInfo.researchExp"] = "yes";
    if (filters.includes("industry")) query["experienceInfo.industryExp"] = "yes";
    const currentFaculty = await Registration.find(query);
    const revealedFaculty = await RevealedFaculty.find(query);
    const facultyData = [...currentFaculty, ...revealedFaculty];
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Faculty Data");
    const chartSheet = workbook.addWorksheet("Chart Data");
    chartSheet.columns = [
      { header: "Category", key: "category" },
      { header: "Count", key: "count" },
    ];
    let columns = [
      { header: "Faculty Name", key: "name" },
      { header: "Faculty ID", key: "facultyID" },
    ];
    if (filters.includes("facultyDetails")) {
      if (subFilters?.facultyDetails?.includes("All Details")) {
          columns.push(
              { header: "Personal Phone", key: "personalPhone" },
              { header: "Alternative Phone", key: "alternativePhone" },
              { header: "Personal Email", key: "personalEmail" },
              { header: "College Email", key: "collegeEmail" },
              { header: "Gender", key: "gender" },
              { header: "Marital Status", key: "maritalStatus" },
              { header: "Caste", key: "caste" },
              { header: "Aadhaar Number", key: "aadhaar" },
              { header: "PAN Number", key: "pan" },
              { header: "Address", key: "address" }
          );
      } 
      else {
        if (subFilters?.facultyDetails?.includes("Phone Number")) {
          columns.push(
            { header: "Personal Phone", key: "personalPhone" },
            { header: "Alternative Phone", key: "alternativePhone" }
          );
        }
        if (subFilters?.facultyDetails?.includes("Email")) {
          columns.push(
            { header: "Personal Email", key: "personalEmail" },
            { header: "College Email", key: "collegeEmail" }
          );
        }
        if (subFilters?.facultyDetails?.includes("Gender"))
          columns.push({ header: "Gender", key: "gender" });
        if (subFilters?.facultyDetails?.includes("Marital Status"))
          columns.push({ header: "Marital Status", key: "maritalStatus" });
        if (subFilters?.facultyDetails?.includes("Caste"))
          columns.push({ header: "Caste", key: "caste" });
        if (subFilters?.facultyDetails?.includes("Aadhaar"))
          columns.push({ header: "Aadhaar Number", key: "aadhaar" });
        if (subFilters?.facultyDetails?.includes("PAN"))
          columns.push({ header: "PAN Number", key: "pan" });
        if (subFilters?.facultyDetails?.includes("Address"))
          columns.push({ header: "Address", key: "address" });
      }
    }
    if (filters.includes("phd")) {
      if (subFilters?.phd?.includes("All Details")) {
          columns.push(
            { header: "PhD Specializations", key: "phdSpecializations" },
            { header: "PhD Statuses", key: "phdStatuses" },
            { header: "PhD Completion Dates", key: "phdCompletionDates" },
            { header: "PhD Certificate Links", key: "phdCompletionCertificates" },
            { header: "PhD Expected Years", key: "phdExpectedYears" },
            { header: "Guide Names", key: "guideNames" },
            { header: "Guide Positions", key: "guidePositions" },
            { header: "Guide Certificate Links", key: "guideCertificates" }
          );
      } else {
          if (subFilters?.phd?.includes("PhD Specialization"))
              columns.push({ header: "PhD Specialization", key: "phdSpecializations" });
          if (subFilters?.phd?.includes("Status")){
            columns.push(
              { header: "PhD Specializations", key: "phdSpecializations" },
              { header: "PhD Status", key: "phdStatuses" }
            );
          }
          if (subFilters?.phd?.includes("Completion Certificate")){
            columns.push(
              { header: "PhD Specializations", key: "phdSpecializations" },
              { header: "PhD Completion Certificate", key: "phdCompletionCertificates" }
            );
          }
          if (subFilters?.phd?.includes("Guide Details")) {
              columns.push(
                  { header: "PhD Specialization", key: "phdSpecializations" },
                  { header: "Guide Name", key: "guideNames" },
                  { header: "Guide Position", key: "guidePositions" },
                  { header: "Guide Certificate Link", key: "guideCertificates" }
              );
          }
          if (subFilters?.phd?.includes("Phone Number")) {
            columns.push(
              { header: "Personal Phone", key: "personalPhone" },
              { header: "Alternative Phone", key: "alternativePhone" }
            );
          }
          if (subFilters?.phd?.includes("Email")) {
            columns.push(
              { header: "Personal Email", key: "personalEmail" },
              { header: "College Email", key: "collegeEmail" }
            );
          }
      }
    }
    if (filters.includes("teaching")) {
      if (subFilters?.teaching?.includes("All Details")) {
        columns.push(
            { header: "Teaching Start Date", key: "teachingStartDate" },
            { header: "Teaching Duration", key: "teachingDuration" },
            { header: "Subjects Taught", key: "subjectsTaught" },
            { header: "Times Taught", key: "timesTaught" }
        );
      } else {
            if (subFilters?.teaching?.includes("Teaching Duration")) 
                columns.push({ header: "Teaching Duration", key: "teachingDuration" });
            if (subFilters?.teaching?.includes("Start Date")) 
                columns.push({ header: "Teaching Start Date", key: "teachingStartDate" });
            if (subFilters?.teaching?.includes("Subjects Taught")) {
                columns.push(
                    { header: "Subjects Taught", key: "subjectsTaught" },
                    { header: "Times Taught", key: "timesTaught" }
                );
            }
            if (subFilters?.teaching?.includes("Phone Number")) {
              columns.push(
                { header: "Personal Phone", key: "personalPhone" },
                { header: "Alternative Phone", key: "alternativePhone" }
              );
            }
            if (subFilters?.teaching?.includes("Email")) {
              columns.push(
                { header: "Personal Email", key: "personalEmail" },
                { header: "College Email", key: "collegeEmail" }
              );
            }
        }
    }
    if (filters.includes("educationDetails")) {
      if (subFilters?.educationDetails?.includes("Education Level")) {
          columns.push({ header: "Education Level", key: "educationLevel" });
      }
      if (subFilters?.educationDetails?.includes("UG")) {
          columns.push(
              { header: "UG University Name", key: "ugUniversityName" },
              { header: "UG Location", key: "ugLocation" },
              { header: "UG Roll Number", key: "ugRollNumber" },
              { header: "UG Specialization", key: "ugSpecialization" },
              { header: "UG Completion Date", key: "ugCompletionDate" },
              { header: "Personal Phone", key: "personalPhone" }
          );
      }
      if (subFilters?.educationDetails?.includes("PG")) {
          columns.push(
              { header: "PG University Name", key: "pgUniversityName" },
              { header: "PG Location", key: "pgLocation" },
              { header: "PG Roll Number", key: "pgRollNumber" },
              { header: "PG Specialization", key: "pgSpecialization" },
              { header: "PG Completion Date", key: "pgCompletionDate" },
              { header: "UG University Name", key: "ugUniversityName" },
              { header: "UG Location", key: "ugLocation" },
              { header: "UG Roll Number", key: "ugRollNumber" },
              { header: "UG Specialization", key: "ugSpecialization" },
              { header: "UG Completion Date", key: "ugCompletionDate" },
              { header: "Personal Phone", key: "personalPhone" }
          );
      }
    }
    if (filters.includes("research")) {
      if (subFilters?.research?.includes("All Details")) {
          columns.push(
              { header: "Research Paper Names", key: "researchNames" },
              { header: "Research Paper Links", key: "researchLinks" },
          );
      } else {    
          if (subFilters.research.includes("Phone Number")) {
              columns.push(
                  { header: "Personal Phone", key: "personalPhone" },
                  { header: "Alternative Phone", key: "alternativePhone" }
              );
          }
          if (subFilters.research.includes("Email")) {
              columns.push(
                  { header: "Personal Email", key: "personalEmail" },
                  { header: "College Email", key: "collegeEmail" }
              );
          }
      }
    }
    if (filters.includes("industry")) {
      if (subFilters?.industry?.includes("Industry Experience")) {
          columns.push(
              { header: "Company Name", key: "company" },
              { header: "Role", key: "role" },
              { header: "Duration", key: "duration" }
          );
      }
      if (subFilters?.industry?.includes("Phone Number")) {
          columns.push(
              { header: "Personal Phone", key: "personalPhone" },
              { header: "Alternative Phone", key: "alternativePhone" }
          );
      }
      if (subFilters?.industry?.includes("Email")) {
          columns.push(
              { header: "Personal Email", key: "personalEmail" },
              { header: "College Email", key: "collegeEmail" }
          );
      }
    }
    if (filters.includes("areaOfInterest")) columns.push({ header: "Areas of Interest", key: "areasOfInterest" });
    if (filters.includes("dateOfJoining")) columns.push({ header: "Date of Joining", key: "dateOfJoining" });
    if (filters.includes("projects")) {
      if (subFilters?.projects?.includes("Project Details")) {
          columns.push(
              { header: "Project Name", key: "projectName" },
              { header: "Domain", key: "projectDomain" },
              { header: "Status", key: "projectStatus" }
          );
      }
      if (subFilters?.projects?.includes("Phone Number")) {
          columns.push(
              { header: "Personal Phone", key: "personalPhone" },
              { header: "Alternative Phone", key: "alternativePhone" }
          );
      }
      if (subFilters?.projects?.includes("Email")) {
          columns.push(
              { header: "Personal Email", key: "personalEmail" },
              { header: "College Email", key: "collegeEmail" }
          );
      }
  }  
    if (filters.includes("competitiveExams")) {
      if (subFilters?.competitiveExams?.includes("Exam Details")) {
          columns.push(
              { header: "Exam Name", key: "examName" },
              { header: "Exam Certificate", key: "examCertificate" },
          );
      } else {
          if (subFilters.competitiveExams.includes("Phone Number")) {
              columns.push(
                  { header: "Personal Phone", key: "personalPhone" },
                  { header: "Alternative Phone", key: "alternativePhone" }
              );
          }
          if (subFilters.competitiveExams.includes("Email")) {
              columns.push(
                  { header: "Personal Email", key: "personalEmail" },
                  { header: "College Email", key: "collegeEmail" }
              );
          }
      }
    }
    if (filters.includes("certifications")) {
      if (subFilters?.certifications?.includes("Certification Details")) {
          columns.push(
              { header: "Certification Name", key: "certificationName" },
              { header: "Provider", key: "certificationProvider" },
              { header: "Certification Link", key: "certificationLink" },
          );
      } else {
          if (subFilters?.certifications?.includes("Phone Number")) {
              columns.push(
                  { header: "Personal Phone", key: "personalPhone" },
                  { header: "Alternative Phone", key: "alternativePhone" }
              );
          }
          if (subFilters?.certifications?.includes("Email")) {
              columns.push(
                  { header: "Personal Email", key: "personalEmail" },
                  { header: "College Email", key: "collegeEmail" }
              );
          }
      }
    }
    if (filters.includes("memberships")) {
      if (subFilters?.memberships?.includes("Membership Name")) {
          columns.push({ header: "Membership Name", key: "membershipName" });
      }
      if (subFilters?.memberships?.includes("Phone Number")) {
          columns.push(
              { header: "Personal Phone", key: "personalPhone" },
              { header: "Alternative Phone", key: "alternativePhone" }
          );
      }
      if (subFilters?.memberships?.includes("Email")) {
          columns.push(
              { header: "Personal Email", key: "personalEmail" },
              { header: "College Email", key: "collegeEmail" }
          );
      }
    }
    columns.push({ header: "Working Status", key: "dateOfReveal" });  
    sheet.columns = columns;
    facultyData.forEach((faculty) => {
      const rawDateOfJoining = faculty.experienceInfo?.dateOfJoining || ""; 
      const extractedDate = rawDateOfJoining.split(" / ")[0]; 
      const dateOfJoining = new Date(extractedDate); 
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (dateOfJoining >= start && dateOfJoining <= end) {
        let rowData = {
          name: faculty.personalInfo.name,
          facultyID: faculty.personalInfo.facultyID,
        };
        let dataRow = {
          name: faculty.personalInfo.name,
          facultyID: faculty.personalInfo.facultyID ,
        };
        let phdData=[]
        let teachingData=[]
        let industryData=[]
        let researchData=[]
        let projectData=[]
        let certificationData=[]
        let examData=[]
        let membershipData=[]
        let hasValidData = false;
        let hasData = false;
        if (filters.includes("facultyDetails")) {
          if (subFilters?.facultyDetails?.includes("All Details")) {
              Object.assign(rowData, {
                  personalPhone: faculty.personalInfo.personalPhone || "",
                  alternativePhone: faculty.personalInfo.alternativePhone || "",
                  personalEmail: faculty.personalInfo.personalEmail || "",
                  collegeEmail: faculty.personalInfo.collegeEmail || "",
                  gender: faculty.personalInfo.gender || "",
                  maritalStatus: faculty.personalInfo.maritalStatus || "",
                  caste: faculty.personalInfo.caste || "",
                  aadhaar: faculty.personalInfo.aadhaar || "",
                  pan: faculty.personalInfo.pan || "",
                  address: faculty.personalInfo.address || "",
              });
          } else {
              if (subFilters?.facultyDetails?.includes("Phone Number")) {
                  Object.assign(rowData, {
                      personalPhone: faculty.personalInfo.personalPhone || "",
                      alternativePhone: faculty.personalInfo.alternativePhone || "",
                  });
              }
              if (subFilters?.facultyDetails?.includes("Email")) {
                  Object.assign(rowData, {
                      personalEmail: faculty.personalInfo.personalEmail || "",
                      collegeEmail: faculty.personalInfo.collegeEmail || "",
                  });
              }
              if (subFilters?.facultyDetails?.includes("Gender")) {
                  rowData.gender = faculty.personalInfo.gender || "";
              }
              if (subFilters?.facultyDetails?.includes("Marital Status")) {
                  rowData.maritalStatus = faculty.personalInfo.maritalStatus || "";
              }
              if (subFilters?.facultyDetails?.includes("Caste")) {
                  rowData.caste = faculty.personalInfo.caste || "";
              }
              if (subFilters?.facultyDetails?.includes("Aadhaar")) {
                  rowData.aadhaar = faculty.personalInfo.aadhaar || "";
              }
              if (subFilters?.facultyDetails?.includes("PAN")) {
                  rowData.pan = faculty.personalInfo.pan || "";
              }
              if (subFilters?.facultyDetails?.includes("Address")) {
                  rowData.address = faculty.personalInfo.address || "";
              }
          }
          hasValidData = true;
        }
        if (filters.includes("phd") && faculty.qualificationInfo?.phdList?.length > 0) {
          faculty.qualificationInfo.phdList.forEach((phd) => {
              let phdRow = {};
              if (subFilters?.phd?.includes("All Details")) {
                  phdRow.phdSpecializations = phd.specialization || "NA";
                  phdRow.phdStatuses = phd.status || "NA";
                  phdRow.phdCompletionDates = phd.status === "completed" ? phd.completionDate || "NA" : "NA";
                  phdRow.phdCompletionCertificates = phd.status === "completed" ? phd.completionCertificate || "NA" : "NA";
                  phdRow.phdExpectedYears = phd.status === "notCompleted" ? phd.expectedYear || "NA" : "NA";
                  phdRow.guideNames = phd.guide === "yes" ? phd.guideName || "NA" : "NA";
                  phdRow.guidePositions = phd.guide === "yes" ? phd.position || "NA" : "NA";
                  phdRow.guideCertificates = phd.guide === "yes" ? phd.guideCertificate || "NA" : "NA";
              } else {
                  if (subFilters?.phd?.includes("PhD Specialization")) 
                      phdRow.phdSpecializations = phd.specialization || "NA";
                  if (subFilters?.phd?.includes("Status")) {
                      phdRow.phdSpecializations = phd.specialization || "NA"; 
                      phdRow.phdStatuses = phd.status || "NA";
                  }
                  if (subFilters?.phd?.includes("Completion Certificate")) {
                      phdRow.phdSpecializations = phd.specialization || "NA";
                      phdRow.phdCompletionCertificates = phd.status === "completed" ? phd.completionCertificate || "NA" : "NA";
                  }
                  if (subFilters?.phd?.includes("Guide Details")) {
                      phdRow.phdSpecializations = phd.specialization || "NA";
                      phdRow.guideNames = phd.guide === "yes" ? phd.guideName || "NA" : "NA";
                      phdRow.guidePositions = phd.guide === "yes" ? phd.position || "NA" : "NA";
                      phdRow.guideCertificates = phd.guide === "yes" ? phd.guideCertificate || "NA" : "NA";
                  }
                }
              phdData.push(phdRow); 
          });
          if (subFilters?.phd?.includes("Phone Number")) {
            phdData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
            phdData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
          }
          if (subFilters?.phd?.includes("Email")) {
            phdData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
            phdData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
          }
          hasData = true;
        }
        if (filters.includes("educationDetails")) {
          if (subFilters?.educationDetails?.includes("Education Level")) {
              rowData.educationLevel = faculty.qualificationInfo?.educationLevel || "NA";
              hasValidData = true;
          }
          if (subFilters?.educationDetails?.includes("UG") && faculty.qualificationInfo?.educationLevel === "UG") {
              rowData.educationLevel = faculty.qualificationInfo.educationLevel || "NA";
              rowData.ugUniversityName = faculty.qualificationInfo.ugUniversityName || "NA";
              rowData.ugLocation = faculty.qualificationInfo.ugLocation || "NA";
              rowData.ugRollNumber = faculty.qualificationInfo.ugRollNumber || "NA";
              rowData.ugSpecialization = faculty.qualificationInfo.ugSpecialization || "NA";
              rowData.ugCompletionDate = faculty.qualificationInfo.ugCompletionDate || "NA";
              rowData.personalPhone = faculty.personalInfo.personalPhone || "NA";
              hasValidData = true;  
          }
          if (subFilters?.educationDetails?.includes("PG") && faculty.qualificationInfo?.educationLevel === "PG") {
              rowData.educationLevel = faculty.qualificationInfo.educationLevel || "NA";
              rowData.pgUniversityName = faculty.qualificationInfo.pgUniversityName || "NA";
              rowData.pgLocation = faculty.qualificationInfo.pgLocation || "NA";
              rowData.pgRollNumber = faculty.qualificationInfo.pgRollNumber || "NA";
              rowData.pgSpecialization = faculty.qualificationInfo.pgSpecialization || "NA";
              rowData.pgCompletionDate = faculty.qualificationInfo.pgCompletionDate || "NA";
              rowData.ugUniversityName = faculty.qualificationInfo.ugUniversityName || "NA";
              rowData.ugLocation = faculty.qualificationInfo.ugLocation || "NA";
              rowData.ugRollNumber = faculty.qualificationInfo.ugRollNumber || "NA";
              rowData.ugSpecialization = faculty.qualificationInfo.ugSpecialization || "NA";
              rowData.ugCompletionDate = faculty.qualificationInfo.ugCompletionDate || "NA";
              rowData.personalEmail = faculty.personalInfo.personalEmail || "NA";
              hasValidData = true;  
          }
        }
        if (filters.includes("research") && faculty.experienceInfo?.researchList?.length > 0) {
          faculty.experienceInfo.researchList.forEach((research) => {
              let researchRow = {};
              if (subFilters?.research?.includes("All Details")) {
                  researchRow.researchName = research.name || "NA";
                  researchRow.researchLink = research.link || "NA";
              }
              researchData.push(researchRow); 
          });
          if (subFilters?.research?.includes("Phone Number")) {
            researchData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
            researchData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
          }
          if (subFilters?.research?.includes("Email")) {
              researchData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
              researchData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
          }
          hasData = true;
        }
        if (filters.includes("teaching") && faculty.experienceInfo?.teachingSubjects?.length > 0) {
          faculty.experienceInfo.teachingSubjects.forEach((subject, index) => {
              let teachingRow = {}; 
              if (subFilters?.teaching?.includes("All Details") && index === 0) {
                  teachingRow.teachingStartDate = faculty.experienceInfo.teachingStartDate || "NA";
                  teachingRow.teachingDuration = faculty.experienceInfo.teachingDuration || "NA";
              }      
              if (subFilters?.teaching?.includes("All Details") || subFilters?.teaching?.includes("Subjects Taught")) {
                  teachingRow.subjectsTaught = subject.subject || "NA";
                  teachingRow.timesTaught = subject.timesTaught || "NA";
              }
              teachingData.push(teachingRow); 
          });
          if (subFilters?.teaching?.includes("Phone Number")) {
              teachingData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
              teachingData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
          }
          if (subFilters?.teaching?.includes("Email")) {
              teachingData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
              teachingData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
          }
          hasData = true;
        }
        if (filters.includes("industry") && faculty.experienceInfo?.industryList?.length > 0) {     
          faculty.experienceInfo.industryList.forEach((industry) => {
              let industryRow = {};
              if (subFilters?.industry?.includes("Industry Experience")) {
                  industryRow.company = industry.company || "NA";
                  industryRow.role = industry.role || "NA";
                  industryRow.duration = industry.duration || "NA";
              }
              industryData.push(industryRow); 
          });
          if (subFilters?.industry?.includes("Phone Number")) {
              industryData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
              industryData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
          }
          if (subFilters?.industry?.includes("Email")) {
              industryData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
              industryData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
          }
          hasData = true;
        }
        if (filters.includes("areaOfInterest") && faculty.additionalDetails?.areasOfInterest?.length > 0) {
          const validInterests = faculty.additionalDetails.areasOfInterest.filter(interest => interest.trim() !== "");
          if (validInterests.length > 0) {
              let interestRow = { ...rowData };  
              interestRow.areasOfInterest = validInterests.join("\n");  
              interestRow.dateOfReveal = faculty.experienceInfo.dateOfReveal || "NA";  
              sheet.addRow(interestRow); 
          }
      }      
        if (filters.includes("dateOfJoining") && faculty.experienceInfo.dateOfJoining) {
            rowData.dateOfJoining = faculty.experienceInfo.dateOfJoining;
            hasValidData = true;
        }
        if (filters.includes("projects") && faculty.additionalDetails?.projects?.length > 0) {
          const validProjects = faculty.additionalDetails.projects.filter(p => p.name !== "NA");
          if (validProjects.length > 0) {
                validProjects.forEach((project) => {
                    let projectRow = {};
                    if (subFilters?.projects?.includes("Project Details")) {
                        projectRow.projectName = project.name || "NA";
                        projectRow.projectDomain = project.domain || "NA";
                        projectRow.projectStatus = project.status || "NA";
                    }
                    projectData.push(projectRow); 
                });
            if (subFilters?.projects?.includes("Phone Number")) {
                  projectData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
                  projectData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
            }
            if (subFilters?.projects?.includes("Email")) {
                projectData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
                projectData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
            }
            hasData = true;
            }
        }
        if (filters.includes("competitiveExams") && faculty.additionalDetails?.examList?.length > 0) {
            const validExams = faculty.additionalDetails.examList.filter(e => e.name !== "NA");
            if (validExams.length > 0) {
                validExams.forEach((exam) => {
                    let examRow = {};
                    if (subFilters?.competitiveExams?.includes("Exam Details")) {
                        examRow.examName = exam.name || "NA";
                        examRow.examCertificate = exam.examCertificate || "NA";
                    }
                    examData.push(examRow); 
                });
            if (subFilters?.competitiveExams?.includes("Phone Number")) {
                  examData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
                  examData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
              }
            if (subFilters?.competitiveExams?.includes("Email")) {
                examData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
                examData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
              }
              hasData = true;
            }
        }
        if (filters.includes("certifications") && faculty.additionalDetails?.certifications?.length > 0) {
          const validCertifications = faculty.additionalDetails.certifications.filter(c => c.name !== "NA");
          if (validCertifications.length > 0) {
              validCertifications.forEach((cert) => {
                  let certRow = {};
                  if (subFilters?.certifications?.includes("Certification Details")) {
                      certRow.certificationName = cert.name || "NA";
                      certRow.certificationProvider = cert.provider || "NA";
                      certRow.certificationLink = cert.certificationLink || "NA";
                  }
                  certificationData.push(certRow); 
              });      
              if (subFilters?.certifications?.includes("Phone Number")) {
                  certificationData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
                  certificationData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
              }
              if (subFilters?.certifications?.includes("Email")) {
                  certificationData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
                  certificationData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
              }
              hasData = true;
          }
        }
        if (filters.includes("memberships") && faculty.additionalDetails?.memberships?.length > 0) {
          const validMemberships = faculty.additionalDetails.memberships.filter(m => m.name !== "NA");
          if (validMemberships.length > 0) {
              validMemberships.forEach((membership) => {
                  let membershipRow = {};
                  if (subFilters?.memberships?.includes("Membership Name")) {
                      membershipRow.membershipName = membership.name || "NA";
                  }
                  membershipData.push(membershipRow); 
              });
              if (subFilters?.memberships?.includes("Phone Number")) {
                  membershipData[0].personalPhone = faculty.personalInfo.personalPhone || "NA";
                  membershipData[0].alternativePhone = faculty.personalInfo.alternativePhone || "NA";
              }
              if (subFilters?.memberships?.includes("Email")) {
                  membershipData[0].personalEmail = faculty.personalInfo.personalEmail || "NA";
                  membershipData[0].collegeEmail = faculty.personalInfo.collegeEmail || "NA";
              }
              hasData = true;
          }
        }      
        if(hasData){
          if (phdData.length > 0) {
            sheet.addRow({ 
                ...rowData, 
                ...phdData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (phdData.length > 1) {  
                phdData.slice(1).forEach(phdRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(rowData).map(key => [key, ""])), 
                        ...phdRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (researchData.length > 0) {
            sheet.addRow({ 
                ...rowData, 
                ...researchData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (researchData.length > 1) {
                researchData.slice(1).forEach(researchRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(rowData).map(key => [key, ""])), 
                        ...researchRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (teachingData.length > 0) {
            sheet.addRow({ 
                ...rowData, 
                ...teachingData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (teachingData.length > 1) {  
                teachingData.slice(1).forEach(teachingRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(rowData).map(key => [key, ""])), 
                        ...teachingRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (industryData.length > 0) {
            sheet.addRow({ 
                ...rowData, 
                ...industryData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (industryData.length > 1) {  
                industryData.slice(1).forEach(industryRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(rowData).map(key => [key, ""])), 
                        ...industryRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (projectData.length > 0) {
            sheet.addRow({ 
                ...dataRow, 
                ...projectData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (projectData.length > 1) {  
                projectData.slice(1).forEach(projectRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(dataRow).map(key => [key, ""])), 
                        ...projectRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (examData.length > 0) {
            sheet.addRow({ 
                ...dataRow, 
                ...examData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (examData.length > 1) {  
                examData.slice(1).forEach(examRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(dataRow).map(key => [key, ""])), 
                        ...examRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (certificationData.length > 0) {
            sheet.addRow({ 
                ...dataRow, 
                ...certificationData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService" 
            });
            if (certificationData.length > 1) {  
                certificationData.slice(1).forEach(certRow => {
                    sheet.addRow({ 
                        ...Object.fromEntries(Object.keys(dataRow).map(key => [key, ""])), 
                        ...certRow, 
                        dateOfReveal: "" 
                    });
                });
            }
          }
          if (membershipData.length > 0) {
            sheet.addRow({
                ...dataRow, 
                ...membershipData[0], 
                dateOfReveal: faculty.experienceInfo.dateOfReveal || "InService"
            });
            if (membershipData.length > 1) {
                membershipData.slice(1).forEach(membershipRow => {
                    sheet.addRow({
                        ...Object.fromEntries(Object.keys(dataRow).map(key => [key, ""])), 
                        ...membershipRow,
                        dateOfReveal: ""
                    });
                });
            }
          }
        }
        if (hasValidData) {
          rowData.dateOfReveal = faculty.experienceInfo.dateOfReveal || "InService";  
          sheet.addRow(rowData);  
        }
      }    
    });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    await workbook.xlsx.write(res);
    res.end();
  } 
  catch (error) {
    console.error("Error exporting data:", error);
    res.status(500).json({ success: false, message: "Error exporting data" });
  }
});
export default router;