import express from "express";
import Registration from "../models/registrationModel.js";
import nodemailer from "nodemailer";
import crypto from "crypto";
import bcrypt from "bcryptjs";

const router = express.Router();
const otpStore = {}; 
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

router.post("/forgot-password", async (req, res) => {
    const { facultyID, email } = req.body;
    try {
      const user = await Registration.findOne({ "personalInfo.facultyID": facultyID });
  
      if (!user) {
        console.log("User not found in the database.");
        return res.status(404).json({ message: "User not found." });
      }
      if (user.personalInfo.personalEmail.trim().toLowerCase() !== email.trim().toLowerCase()) {
        console.log("Email mismatch:", user.personalInfo.personalEmail, "!=", email);
        return res.status(400).json({ message: "Email does not match." });
      }
      const otp = crypto.randomInt(100000, 999999).toString();
      otpStore[facultyID] = otp;  
      const mailOptions = {
        from: "lekhya1854@gmail.com",
        to: email,
        subject: "Password Reset OTP",
        text: `Your OTP for password reset is: ${otp}. It is valid for 5 minutes.`,
      };
  
      await transporter.sendMail(mailOptions);
      res.json({ message: "OTP sent successfully." });
  
      setTimeout(() => delete otpStore[facultyID], 300000);
    } catch (error) {
      console.error("Server error:", error);
      res.status(500).json({ message: "Server error. Try again later." });
    }
  });
  
router.post("/verify-otp", (req, res) => {
  const { facultyID, otp } = req.body;

  if (otpStore[facultyID] !== otp) {
    return res.status(400).json({ message: "Invalid OTP." });
  }

  delete otpStore[facultyID];
  res.json({ message: "OTP verified. Proceed to reset password." });
});

router.post("/reset-password", async (req, res) => {
  const { facultyID, newPassword } = req.body;

  try {
    const user = await Registration.findOne({ "personalInfo.facultyID": facultyID });

    if (!user) return res.status(404).json({ message: "User not found." });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;

    await user.save();
    res.json({ message: "Password reset successfully." });
  } catch (error) {
    res.status(500).json({ message: "Server error." });
  }
});

export default router;
