import express from "express";
import Registration from "../models/registrationModel.js";
import { verifyFaculty } from "./authRoutes.js";
import { spawn } from "child_process";
const router = express.Router();

router.post("/chatbot", verifyFaculty, async (req, res) => {
  try {
    const { query } = req.body;
    const result = await runPythonChatbot(query);
    if (result?.answer) {
      return res.json({ message: result.answer });
    }
    res.status(500).json({ message: "AI failed to answer. Try again." });
  } catch (error) {
    console.error("Chatbot Error:", error);
    res.status(500).json({ message: "Server error." });
  }
});

function runPythonChatbot(query) {
  return new Promise((resolve, reject) => {
    const python = spawn("python", ["./scripts/ai_chatbot.py", query]);
    let data = "";
    python.stdout.on("data", (chunk) => data += chunk.toString());
    python.stderr.on("data", (err) => console.error("Python Error:", err.toString()));
    python.on("close", () => {
      try {
        const result = JSON.parse(data);
        resolve(result);
      } catch (e) {
        reject(e);
      }
    });
  });
}

router.get("/profile", verifyFaculty, async (req, res) => {
    try {
      const faculty = await Registration.findOne(
        { "personalInfo.facultyID": req.faculty.facultyID },
        { password: 0 } 
      );
      if (!faculty) {
        return res.status(404).json({ success: false, message: "Faculty profile not found" });
      }
      res.json(faculty); 
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ success: false, message: "Error fetching profile" });
    }
});
router.post("/update-profile", verifyFaculty, async (req, res) => {
    try {
        const { facultyID } = req.faculty; 
        const updatedData = req.body; 
        const faculty = await Registration.findOneAndUpdate(
            { "personalInfo.facultyID": facultyID },
            { $set: updatedData },
            { new: true } 
        );
        if (!faculty) {
            return res.status(404).json({ success: false, message: "Faculty not found" });
        }
        res.json({ success: true, message: "Profile updated successfully!", updatedProfile: faculty });
    } catch (error) {
        console.error("Error updating profile:", error);
        res.status(500).json({ success: false, message: "Server error. Please try again later." });
    }
});
router.post("/end-edit", verifyFaculty, async (req, res) => {
    try {
        const { facultyID } = req.faculty;
        const faculty = await Registration.findOneAndUpdate(
            { "personalInfo.facultyID": facultyID },
            { $set: { editRequestStatus: "None" } },
            { new: true }
        );
        if (!faculty) {
            return res.status(404).json({ success: false, message: "Faculty not found" });
        }
        res.json({ success: true, message: "Editing completed successfully!", updatedProfile: faculty });
    } catch (error) {
        console.error("Error ending edit session:", error);
        res.status(500).json({ success: false, message: "Server error. Please try again later." });
    }
});
router.post("/request-edit", verifyFaculty, async (req, res) => {
    try {
      const facultyID = req.faculty.facultyID; 
      const faculty = await Registration.findOne({ "personalInfo.facultyID": facultyID });
      if (!faculty) {
        return res.status(404).json({ success: false, message: "Faculty not found." });
      }
      if (faculty.editRequestStatus === "Pending") {
        return res.status(400).json({ success: false, message: "Edit request already pending." });
      }
      faculty.editRequestStatus = "Pending";
      await faculty.save();
      res.json({ success: true, message: "Edit request sent successfully." });
    } catch (error) {
      console.error("Error processing edit request:", error);
      res.status(500).json({ success: false, message: "Server error. Try again later." });
    }
});
export default router;