import express from "express";
import Registration from "../models/registrationModel.js";
const router = express.Router();
router.post("/submit", async (req, res) => {
  try {
    console.log("Received Request Body:", JSON.stringify(req.body, null, 2));
    if (!req.body.personalInfo || !req.body.qualificationInfo || !req.body.experienceInfo) {
      return res.status(400).json({ success: false, error: "Missing required fields" });
    }
    if (!req.body.personalInfo.facultyID) {
      return res.status(400).json({ success: false, error: "Faculty ID is required." });
    }
    req.body.password = req.body.personalInfo.facultyID;
    const newRegistration = new Registration(req.body);
    await newRegistration.save();
    console.log("Data Saved Successfully");
    res.status(201).json({ success: true, message: "Registration successful" });
  } catch (error) {
    console.error("Error Saving Data:", error);
    res.status(400).json({ success: false, error: error.message });
  }
});
router.get("/all", async (req, res) => {
  try {
    const registrations = await Registration.find().lean(); 
    res.status(200).json(registrations);
  } catch (error) {
    console.error("Error Fetching Data:", error);
    res.status(500).json({ success: false, error: "Server error while fetching data" });
  }
});
export default router;
