import mongoose from "mongoose";

const registrationSchema = new mongoose.Schema({
  personalInfo: {
    name: String,
    personalPhone: String,
    alternativePhone: String,
    personalEmail: String,
    collegeEmail: String,
    gender: String,
    maritalStatus: String,
    caste: String,
    facultyID: { type: String, required: true, unique: true }, 
    aadhaar: String,
    pan: String,
    address: String,
  },
  qualificationInfo: {
    educationLevel: String, 
    ugUniversityName: String,
    ugLocation: String,
    ugRollNumber: String,
    ugSpecialization: String,
    ugCompletionDate: String,
    pgUniversityName: String,
    pgLocation: String,
    pgRollNumber: String,
    pgSpecialization: String,
    pgCompletionDate: String,
    phdStatus: String, 
    phdList: [
      {
        specialization: String,
        status: String, 
        completionDate: String, 
        completionCertificate: String,
        expectedYear: String, 
        guide: String,
        guideName: String, 
        position: String, 
        guideCertificate: String, 
      },
    ],
  },
  experienceInfo: {
    teachingExp: String, 
    teachingStartDate: String, 
    teachingDuration: String, 
    teachingSubjects: [
      {
        subject: String,
        timesTaught: String,
      },
    ],
    researchExp: String, 
    researchList: [
      {
        name: String,
        link: String, 
      },
    ],
    industryExp: String, 
    industryList: [
      {
        company: String,
        role: String,
        duration: String,
      },
    ],
    dateOfJoining: String,
    dateOfReveal: { type: String, default: "InService" },
  },
  additionalDetails: {
    areasOfInterest: [String],
    examList: [
      {
        name: String,
        examCertificate: String, 
      },
    ],
    certifications: [
      {
        name: String,
        provider: String,
        certificationLink: String, 
      },
    ],
    projects: [
      {
        name: String,
        domain: String,
        status: String, 
      },
    ],
    memberships: [
      {
        name: String,
      },
    ],
  },
  uploads: {
    aadharCard: String, 
    panCard: String, 
    passportPhoto: String, 
  },
  password: { type: String, required: true }, 
  editRequestStatus: { type: String, default: "None" },
});

registrationSchema.pre("save", function (next) {
  if (!this.password) {
    this.password = this.personalInfo.facultyID; 
  }
  next();
});

const Registration = mongoose.model("Registration", registrationSchema);
export default Registration;
